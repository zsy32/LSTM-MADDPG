import os
import time
import torch
import random

import numpy as np
import matplotlib.pyplot as plt

from tqdm  import tqdm

from agent import Agent_Low
from agent import Agent_High

from common.replay_buffer       import Buffer_High
from common.replay_buffer       import Buffer_Low

from policy_high.actor_critic_high import gCritic


class Runner:
    def __init__(self, args, env):
        self.args    = args
        self.noise   = args.noise_rate

        self.env    = env
        # upper agent for weight
        self.agents_high = self._init_agents_high()
        self.buffer_high = Buffer_High(args)

        # lower agent for path, re-define agent for Single-Agent Algorithm
        self.agents_low  =  self._init_agents_low()
        # initial buffer for each lower agent
        self.buffers_low = []
        for rtype in range(4):
            buffer_low = Buffer_Low(args, rtype)
            self.buffers_low.append(buffer_low)

        self.rtype = 0

        self.global_critic = gCritic(args)
        self.target_global_critic = gCritic(args)
        self.gCritic_optim = torch.optim.Adam(self.global_critic.parameters(), lr=self.args.lr_high_critic)

        self.epsilon       = args.epsilon
        self.episode_limit = args.max_episode_len
        
        self.save_path = self.args.save_dir + '/' + self.args.scenario_name
        if not os.path.exists(self.save_path):
            os.makedirs(self.save_path)

        self.grad_method = self.args.grad_method
        print("Initial time for each request: {}".format(self.args.my_request_times))


    def _init_logs(self):
        self.log_delay_files      = []
        self.log_throughput_files = []
        self.log_loss_files       = []
        self.log_reward_files     = []
        
        log_dir = self.args.log_dir
        os.makedirs(log_dir)
        for i in range(4):
            log_delay_file      = open("%s/delay_type%d.log" % (log_dir, i), "w", 1)
            self.log_delay_files.append(log_delay_file)

            log_throughput_file = open("%s/throughput_type%d.log" % (log_dir, i), "w", 1)
            self.log_throughput_files.append(log_throughput_file)

            log_loss_file       = open("%s/loss_type%d.log" % (log_dir, i), "w", 1)
            self.log_loss_files.append(log_loss_file)

            log_reward_file     = open("%s/reward_type%d.log" % (log_dir, i), "w", 1)
            self.log_reward_files.append(log_reward_file)

        self.log_path_file      = open("%s/path.log"   % (log_dir), "w", 1)
        self.log_weight_file    = open("%s/weight.log" % (log_dir), "w", 1)
        self.log_high_rwd_file  = open("%s/high_rwd.log" % (log_dir), "w", 1)


    def _init_logs_eval(self):
        self.log_delay_files      = []
        self.log_throughput_files = []
        self.log_loss_files       = []
        self.log_reward_files     = []
        
        log_dir_eval = self.args.log_dir_eval
        os.makedirs(log_dir_eval)
        for i in range(4):
            log_delay_file      = open("%s/delay_type%d.log" % (log_dir_eval, i), "w", 1)
            self.log_delay_files.append(log_delay_file)

            log_throughput_file = open("%s/throughput_type%d.log" % (log_dir_eval, i), "w", 1)
            self.log_throughput_files.append(log_throughput_file)

            log_loss_file       = open("%s/loss_type%d.log" % (log_dir_eval, i), "w", 1)
            self.log_loss_files.append(log_loss_file)

            log_reward_file     = open("%s/reward_type%d.log" % (log_dir_eval, i), "w", 1)
            self.log_reward_files.append(log_reward_file)

        self.log_path_file      = open("%s/path.log"   % (log_dir_eval), "w", 1)
        self.log_weight_file    = open("%s/weight.log" % (log_dir_eval), "w", 1)
        self.log_high_rwd_file  = open("%s/high_rwd.log" % (log_dir_eval), "w", 1)


    def _init_agents_high(self):
        agents = []
        for i in range(self.args.n_agents):
            agent = Agent_High(i, self.args)
            agents.append(agent)
        return agents


    def _init_agents_low(self):
        agents = []
        for i in range(self.args.n_agents):
            agent = Agent_Low(i, self.args)
            agents.append(agent)
        return agents
    

    def _load_agents(self):
        print("loading trained model")
        for i in range(self.args.n_agents):
            model_path = os.path.join(self.args.save_dir, self.args.scenario_name)
            model_path = os.path.join(model_path, 'agent_%d' % i)
            self.agents_high[i].policy.actor_network.load_state_dict(torch.load(model_path + '/' + '199_actor_params.pkl'))
            self.agents_low[i].policy.actor_network.load_state_dict(torch.load(model_path + '/'  + '199_lower_actor_params.pkl'))


    def get_high_reward(self, s_high, a_high):
        reward = []
        for i in range(len(s_high)):
            # avg_delay = s_high[i][1] * self.args.delay_base
            # if (avg_delay < self.args.delay_base):
            #     reward.append(5)
            # else:
            #     reward.append(0)
            # reward.append( self.get_reward( i, s_high[i][1], s_high[i][2], s_high[i][3] ) * s_high[i][0])
            reward.append(-abs(s_high[i][0] - a_high[i]))

        print("Reward: ", reward)
        return reward
    

    def get_high_weight(self, s_high, a_high):
        state_weight = []
        for i in range(len(s_high)):
            state_weight.append(s_high[i][0])

        a = 0.99
        b = 0.01

        cat_actions_high = torch.cat((a*state_weight[0] + b*a_high[0] , \
                                        a*state_weight[1] + b*a_high[1] , \
                                        a*state_weight[2] + b*a_high[2] , \
                                        a*state_weight[3] + b*a_high[3] ), 1)

        actions_high = torch.nn.functional.softmax(cat_actions_high).tolist()[0]
        
        print("Actin weight: ", a_high)
        print("State weight: ", state_weight)
        print("Conct weight: ", cat_actions_high)
        print("Final weight: ", actions_high)

        return actions_high



    def get_reward(self, rtype,  delay, throughput, loss_rate):

        delay_cut  = min(1000, delay) # since 1000 is much larger than common delay
        delay_scaled = delay_cut / 1000
        delay_sq = - delay_scaled
        
        loss_scaled = loss_rate / (0.01)
        loss_sq = - loss_scaled
        
        throughput_log = np.log(0.5 + throughput) #avoid nan
        
        # calc global rwd of the generated path 
        global_rwd = 0
        if rtype == 0:
            global_rwd = 1 * delay_sq
        elif rtype == 1:
            global_rwd =  0. * (delay_sq) + 1 * throughput_log 
        elif rtype == 2:
            global_rwd = 0.5 * delay_sq + 0.5 * throughput_log
        else:
            global_rwd = 0.5 * delay_sq + 0.5 * loss_sq

        return global_rwd


    def run(self):
        self._init_logs()
        returns = []
        # statistics about choosing paths (SHR or WP)
        action_history = {}
        action_history["agent0"] = [0 for i in range(self.args.num_paths)]
        action_history["agent1"] = [0 for i in range(self.args.num_paths)]
        action_history["agent2"] = [0 for i in range(self.args.num_paths)]
        action_history["agent3"] = [0 for i in range(self.args.num_paths)]

        for time_step in tqdm(range(self.args.time_steps)):
            if time_step % self.episode_limit == 0:
                s_low, critic_s, rtype = self.env.han_reset()
                s_high = critic_s
                self.rtype = rtype

            # every 40 steps, change bandwidth of links
            if time_step > 0 and time_step % 1 == 0:
                s_high_next = critic_s_next
                actions_high = []
                with torch.no_grad():
                    for agent_id, agent_high in enumerate(self.agents_high):
                        action_resource_weight = agent_high.select_action(s_high[agent_id], self.noise, self.epsilon)
                        actions_high.append(action_resource_weight)

                    actions_high = self.get_high_weight(s_high, actions_high)
                    self.env.han_step_high_weight(actions_high) 
                
                    r_high = self.get_high_reward(s_high, actions_high)
                    u_high = actions_high

                    # add to log file
                    print(u_high, file=self.log_weight_file)
                    print(r_high, file=self.log_high_rwd_file)

                    self.buffer_high.store_episode(s_high, u_high, r_high, s_high_next, critic_s, critic_s_next)
                    s_high = s_high_next

            # every step, an agent is selected by rtype to make lower action
            agent_id = self.rtype
            with torch.no_grad():
                action_low = self.agents_low[agent_id].select_action(s_low, self.noise, self.epsilon)
                u_low = action_low
                action_history["agent{}".format(agent_id)][action_low.argmax().numpy()] += 1

            action_for_env = action_low.argmax().numpy()
            s_low_next, r_low, critic_s_next, rtype = self.env.han_step_low_path(action_for_env, 
                                            self.log_delay_files, 
                                            self.log_throughput_files, 
                                            self.log_loss_files, 
                                            self.log_reward_files, 
                                            self.log_path_file)
            self.rtype  = rtype

            # print("before buffers_low store_episode:")
            # print(s_low, u_low, r_low, s_low_next)
            self.buffers_low[agent_id].store_episode(s_low, u_low, r_low, s_low_next)
            s_low = s_low_next
            critic_s = critic_s_next

            # when to learning for agent of different level
            if self.buffer_high.current_size >= self.args.batch_size:
                transitions = self.buffer_high.sample(self.args.batch_size)

                for agent_high in self.agents_high:
                    other_agents = self.agents_high.copy()
                    other_agents.remove(agent_high)
                    agent_high.pareto_learn(transitions, other_agents, self.global_critic, self.target_global_critic, self.gCritic_optim)
                    
             #and time_step % 80 == 0:
            for rtype in range(4):
                if self.buffers_low[rtype].current_size >= self.args.batch_size:
                    transitions = self.buffers_low[rtype].sample(self.args.batch_size)
                    self.agents_low[rtype].learn(transitions)
            
            # self.noise   = max(0.05, self.noise - 0.0000005)
            self.epsilon = max(0.005, self.epsilon - 0.0005)

        print(action_history)


    def random_pick(self, some_list, probabilities):
        x=random.uniform(0,1)
        cumulative_probability=0.0
        for item,item_probability in zip(some_list,probabilities):
            cumulative_probability+=item_probability
            if x < cumulative_probability: break
        return item


    def run_eval(self):
        self._load_agents()
        self._init_logs_eval()

        action_history = {}
        action_history["agent0"] = [0 for i in range(self.args.num_paths)]
        action_history["agent1"] = [0 for i in range(self.args.num_paths)]
        action_history["agent2"] = [0 for i in range(self.args.num_paths)]
        action_history["agent3"] = [0 for i in range(self.args.num_paths)]

        for time_step in tqdm(range(self.args.time_steps)):
            if time_step % self.episode_limit == 0:
                s_low, critic_s, rtype = self.env.han_reset()
                s_high = critic_s
                self.rtype = rtype

            if time_step > 0 and time_step % 40 == 0:
                s_high_next = critic_s_next
                actions_high = []
                with torch.no_grad():
                    for agent_id, agent_high in enumerate(self.agents_high):
                        action_resource_weight = agent_high.select_action(s_high[agent_id], self.noise, self.epsilon)
                        actions_high.append(action_resource_weight)

                    cat_actions_high = torch.cat((actions_high[0], actions_high[1], actions_high[2], actions_high[3]), 1)
                    actions_high = torch.nn.functional.softmax(cat_actions_high).tolist()[0]
                    print("\t\t", actions_high)
                    self.env.han_step_high_weight(actions_high) # softmax should be used inside step() or here
                
                    r_high = self.get_high_reward(s_high, actions_high)
                    u_high = actions_high
 
                    print(u_high, file=self.log_weight_file)
                    print(r_high, file=self.log_high_rwd_file)

                    self.buffer_high.store_episode(s_high, u_high, r_high, s_high_next, critic_s, critic_s_next)
                    s_high = s_high_next
            
            agent_id = self.rtype
            with torch.no_grad():
                # print(s_low)
                action_low = self.agents_low[agent_id].select_action(s_low, self.noise, self.epsilon)
                u_low = action_low
                action_proba = action_low.tolist()[0]
                # print("Low action probability: ", action_proba)

            action_for_env = self.random_pick( [i for i in range(self.args.num_paths)], action_proba )
            # action_for_env = action_proba.argmax().numpy()

            # action_for_env = 1-action_for_env
            action_history["agent{}".format(agent_id)][action_for_env] += 1
            s_low_next, r_low, critic_s_next, rtype = self.env.han_step_low_path(action_for_env, 
                                            self.log_delay_files, 
                                            self.log_throughput_files, 
                                            self.log_loss_files, 
                                            self.log_reward_files, 
                                            self.log_path_file)
            self.rtype  = rtype

            # print("before buffers_low store_episode:")
            # print(s_low, u_low, r_low, s_low_next)
            self.buffers_low[agent_id].store_episode(s_low, u_low, r_low, s_low_next)
            s_low = s_low_next
            critic_s = critic_s_next

            self.epsilon = max(0.005, self.epsilon - 0.0005)
        print(action_history)

