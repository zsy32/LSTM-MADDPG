import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F


# define the actor network
class Actor_High(nn.Module):
    def __init__(self, args, agent_id):
        super(Actor_High, self).__init__()
        # self.max_action = args.high_action
        # self.input = args.obs_shape[agent_id]
        self.args = args

        self.input_o1 = nn.Linear(1, 1)
        self.input_o2 = nn.Linear(3, 1)

        self.weight_out = nn.Linear(2, 1)
        self.weight_trans = nn.Linear(1, 1)

    def forward(self, x):
        p1 = x[0][0:1].unsqueeze(0)
        p2 = x[0][1:4].unsqueeze(0)

        x1 = F.sigmoid(self.input_o1(p1))
        x2 = F.sigmoid(self.input_o2(p2))
        
        concat = torch.cat((x1, x2), 1)
        weight = F.sigmoid( self.weight_out(concat) )
        weight = F.sigmoid( self.weight_trans(weight) )

        return weight


class Critic_High(nn.Module):
    def __init__(self, args):
        super(Critic_High, self).__init__()

        # self.fc1 = nn.Linear(sum(args.obs_shape) + sum(args.action_shape), 64)
        # self.fc2 = nn.Linear(64, 64)
        # self.fc3 = nn.Linear(64, 64)
        # self.q_out = nn.Linear(64, 1)

        self.input_o = nn.Linear(4, 4)
        self.input_a = nn.Linear(1, 1)
        self.q_out = nn.Linear(5, 1)

    def forward(self, state, action):

        x = self.input_o(state)
        a = self.input_a(action)

        final = torch.cat((x, a), 1)
        q_value = self.q_out(final)

        return q_value


class gCritic(nn.Module):
    def __init__(self, args):
        super(gCritic, self).__init__()
        # self.max_action = args.high_action
        self.fc1 = nn.Linear(16 + 4, 64)
        # self.fc1 = nn.Linear(sum(args.obs_shape) + args.n_agents, 64)
        self.fc2 = nn.Linear(64, 64)
        self.fc3 = nn.Linear(64, 64)
        self.q_out = nn.Linear(64, 1)

    def forward(self, state, action):

        action = torch.cat(action, dim=1)
        action = action.view(1, -1)
        action = action[0]

        state = torch.cat(state, dim=1)
        state = state.view(1, -1)
        state = state[0]

        x = torch.cat([state, action], dim=0)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = F.relu(self.fc3(x))
        q_value = self.q_out(x)
        return q_value