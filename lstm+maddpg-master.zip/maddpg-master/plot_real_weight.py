import numpy as np
import matplotlib.pyplot as plt  

file_name = "maddpg_pareto_bidecision_slice/net_env/st_file_GEA.txt"

f = open(file_name, "r")
lines = f.readlines()

import collections
# initializing deque
de = collections.deque([])

x = []
w1 = []
w2 = []
w3 = []
w4 = []

all_b = 0
b1 = 0
b2 = 0
b3 = 0
b4 = 0
band_type_dict = {0 : b1, 1: b2, 2: b3, 3: b4}

b_dict = {0 : 100, 1: 1500, 2: 1500, 3: 500}


j = 0
for i, line in enumerate(lines):
    lien = line.split(",")
    type_i = int(lien[-1])

    if i < 50:
        de.append([type_i])
        all_b += b_dict[type_i]
        band_type_dict[type_i] += b_dict[type_i]
    else:
        pop_type = de.popleft()[0]
        print(pop_type)
        all_b -= b_dict[pop_type]
        band_type_dict[pop_type] -= b_dict[pop_type]

        de.append([type_i])
        all_b += b_dict[type_i]
        band_type_dict[type_i] += b_dict[type_i]

        print(len(de))

        x.append(j)
        w1.append(band_type_dict[0] / all_b)
        w2.append(band_type_dict[1] / all_b)
        w3.append(band_type_dict[2] / all_b)
        w4.append(band_type_dict[3] / all_b)
        j += 1



l1 = plt.plot(x,w1,"r-",label = "type1")
l2 = plt.plot(x,w2,"g-",label = "type2")
l3 = plt.plot(x,w3,"b-",label = "type3")
l4 = plt.plot(x,w4,"y-",label = "type4")
# plt.plot(x,w1,"ro-",x,w2,"g+-",x,w3,"b^-", x,w4,"y--")

# plt.plot(x,w1,"r-")
plt.plot(x,w1,"r-",x,w2,"g-",x,w3,"b-", x,w4,"y-")


plt.title("The Lasers in Three Conditions")

plt.xlabel("Step")
plt.ylabel("Weight Percent")
plt.legend()

plt.savefig("weight_real.png")