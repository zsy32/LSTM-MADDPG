import pandas as pd
import matplotlib.pyplot as plt


def bar_csv_gen(shr_dir, wp_dir, qos_dir, drl_or_dir, maddpg_dir, maddpg_pareto_dir, target_delay_name, target_thrpt_name, target_loss_name):
	bar_csv_file = open(target_delay_name, "w")
	print("Method\tDelay\tFlow Type", file = bar_csv_file)
	# print("Delay")
	for i in range(4):
		# if i == 1:
			# continue
		get_avg_val(shr_dir + "/delay_type%d.log" % (i), bar_csv_file, "shr type%d" % (i), "Flow type%d Delay" % (i))
		get_avg_val(wp_dir  + "/delay_type%d.log" % (i), bar_csv_file, "wp type%d" % (i), "Flow type%d Delay" % (i))
		get_avg_val(qos_dir + "/delay_type%d.log" % (i), bar_csv_file, "qos type%d" % (i), "Flow type%d Delay" % (i))

		get_avg_val(drl_or_dir + "/delay_type%d.log" % (i), bar_csv_file, "drl-or type%d" % (i), "Flow type%d Delay" % (i))
		get_avg_val(maddpg_dir + "/delay_type%d.log" % (i), bar_csv_file, "maddpg type%d" % (i), "Flow type%d Delay" % (i))
		get_avg_val(maddpg_pareto_dir + "/delay_type%d.log" % (i), bar_csv_file, "Our type%d" % (i), "Flow type%d Delay" % (i))
	bar_csv_file.close()


	bar_csv_file = open(target_thrpt_name, "w")
	print("Method\tThrpt Ratio\tFlow Type", file = bar_csv_file)
	# print("Thrpt Ratio")
	for i in range(4):
		# if i == 0 or i == 3:
			# continue
		get_avg_val_thr(shr_dir + "/throughput_type%d.log" % (i), bar_csv_file, "shr type%d" % (i), "Flow type%d Thrpt ratio" % (i))
		get_avg_val_thr(wp_dir  + "/throughput_type%d.log" % (i), bar_csv_file, "wp type%d" % (i), "Flow type%d Thrpt ratio" % (i))
		get_avg_val_thr(qos_dir + "/throughput_type%d.log" % (i), bar_csv_file, "qos type%d" % (i), "Flow type%d Thrpt ratio" % (i))

		get_avg_val_thr(drl_or_dir + "/throughput_type%d.log" % (i), bar_csv_file, "drl-or type%d" % (i), "Flow type%d Thrpt ratio" % (i))
		get_avg_val_thr(maddpg_dir + "/throughput_type%d.log" % (i), bar_csv_file, "maddpg type%d" % (i), "Flow type%d Thrpt ratio" % (i))
		get_avg_val_thr(maddpg_pareto_dir + "/throughput_type%d.log" % (i), bar_csv_file, "Our type%d" % (i), "Flow type%d Thrpt ratio" % (i))
	bar_csv_file.close()


	bar_csv_file = open(target_loss_name, "w")
	print("Method\tLoss Ratio\tFlow Type", file = bar_csv_file)
	# print("Loss Ratio")
	for i in range(4):
		# if i != 3:
			# continue
		get_avg_val(shr_dir + "/loss_type%d.log" % (i), bar_csv_file, "shr type%d" % (i), "Flow type%d Loss ratio" % (i))
		get_avg_val(wp_dir  + "/loss_type%d.log" % (i), bar_csv_file, "wp type%d" % (i), "Flow type%d Loss ratio" % (i))
		get_avg_val(qos_dir + "/loss_type%d.log" % (i), bar_csv_file, "qos type%d" % (i), "Flow type%d Loss ratio" % (i))

		get_avg_val(drl_or_dir + "/loss_type%d.log" % (i), bar_csv_file, "drl-or type%d" % (i), "Flow type%d Loss ratio" % (i))
		get_avg_val(maddpg_dir + "/loss_type%d.log" % (i), bar_csv_file, "maddpg type%d" % (i), "Flow type%d Loss ratio" % (i))
		get_avg_val(maddpg_pareto_dir + "/loss_type%d.log" % (i), bar_csv_file, "Our type%d" % (i), "Flow type%d Loss ratio" % (i))
	bar_csv_file.close()


def get_avg_val(file_name, csv_file, term_name, type_name):
	f = open(file_name, "r")
	y = f.readlines()
	y = [a.strip() for a in y]
	y = [float(a) for a in y]

	val = sum(y) / len(y)
	# print(val)
	print("{}\t{}\t{}".format(term_name, str(val), type_name), file = csv_file)

def get_avg_val_thr(file_name, csv_file, term_name, type_name):
	f = open(file_name, "r")
	y = f.readlines()
	y = [a.strip() for a in y]
	y = [float(a) for a in y]

	val = sum(y) / len(y)
	if val > 1.0:
		val = 1.0
	# print(val)
	print("{}\t{}\t{}".format(term_name, str(val), type_name), file = csv_file)

def plot_matric_cmp(topo_name, metric_name, load, metric_col, title):
    data = pd.read_csv("plot_csv_folder/{}_{}_{}.csv".format(topo_name, metric_name, load), sep='\t')
    # converting column data to list
    methods = data['Method'].tolist()
    method = [x.split()[0] for x in methods]

    x = list(range(len(method)))
    # sort the metric by flow type in the chart as ['Flow type0 Delay', 'Flow type1 Delay', 'Flow type2 Delay', 'Flow type3 Delay']
    flow_type = set(data['Flow Type'].tolist())
    flow_type = sorted(flow_type)

    l_idx = 0
    r_idx = 0
    for type_name in flow_type:
        delay  = data[data['Flow Type'] == type_name][metric_col].tolist()
        r_idx = l_idx + len (delay)
        new_x = x[l_idx : r_idx]
        # print(new_x)
        # print(delay)
        # for i in range(len(delay)):
        #     if metric_name == "thrpt" and delay[i] > 1.0:
        #         delay[i] = 1.0
        plt.bar(new_x, delay, label = type_name.split()[1])
        l_idx = r_idx
    #柱子上的数字显示
    x_text = x
    delay_text = data[metric_col].tolist()
    for a,b in zip(x, delay_text):   
        plt.text(a, b, '%.2f'%b, ha='center', va='bottom', fontsize=6)
    plt.xticks(x, method, rotation=85)
    plt.xlabel("Method")
    plt.ylabel("Average {}".format(metric_col))
    if metric_name == "thrpt":
        if load == "50":
            plt.ylim(0.6, 1.0)
        else:
            plt.ylim(0.8, 1.0)
    plt.legend(bbox_to_anchor=(1.04,1), loc="upper left")
    plt.title("{} comparison under {} load in {}".format(metric_col, title, topo_name))
    plt.tight_layout()
    plt.savefig("plot_csv_folder/img/{}_{}_{}.png".format(topo_name, load, metric_name))


bar_csv_gen("log/Abi_SHR_8000_10", "log/Abi_WP_8000_10", "log/Abi_QoS_8000_10", 
				"drl-or/log/abi-10-2000", 
				"maddpg_pareto/log/myabi-origin-10-2000", 
				"maddpg_pareto/log_evaluate/Abi-pareto-10-[0.05, 0.05, 0.05, 0.05]-5e-05-5e-05-True-1-2-9-uniDemand-False-0.99-30-5e-05-0.98-1001-01-reward-for-evaluate-2021-06-01", 
				"plot_csv_folder/abi_delay_10.csv", "plot_csv_folder/abi_thrpt_10.csv", "plot_csv_folder/abi_loss_10.csv")


bar_csv_gen("log/Abi_SHR_8000_30", "log/Abi_WP_8000_30", "log/Abi_QoS_8000_30", 
				"drl-or/log/abi-30-2000", 
				"maddpg_pareto/log/myabi-origin-30-2000", 
				"maddpg_pareto/log_evaluate/Abi-pareto-30-[0.05, 0.05, 0.05, 0.05]-5e-05-5e-05-True-1-2-9-uniDemand-False-0.99-30-5e-05-0.98-1001-01-reward-for-evaluate-2021-06-01", 
				"plot_csv_folder/abi_delay_30.csv", "plot_csv_folder/abi_thrpt_30.csv", "plot_csv_folder/abi_loss_30.csv")


bar_csv_gen("log/Abi_SHR_8000_50", "log/Abi_WP_8000_50", "log/Abi_QoS_8000_50", 
				"drl-or/log/abi-50-2000", 
				"maddpg_pareto/log/myabi-origin-50-2000", 
				"maddpg_pareto/log_evaluate/Abi-pareto-50-[0.05, 0.05, 0.05, 0.05]-5e-05-5e-05-True-1-2-9-uniDemand-False-0.99-30-5e-05-0.98-1001-continuous-reward-for-evaluate-2021-06-03-4model", 
				"plot_csv_folder/abi_delay_50.csv", "plot_csv_folder/abi_thrpt_50.csv", "plot_csv_folder/abi_loss_50.csv")

# bar_csv_gen("log/Abi_SHR_8000_50", "log/Abi_WP_8000_50", "log/Abi_QoS_8000_50", 
# 				"drl-or/log/abi-50-2000", 
# 				"maddpg_pareto/log/myabi-origin-50-2000", 
# 				"maddpg_pareto_bidecision/log_evaluate/Abi-pareto-50-[0.05, 0.05, 0.05, 0.05]-5e-05-5e-05-True-1-2-9-uniDemand-False-0.99-30-5e-05-0.98-1001-continuous-reward-for-evaluate-2021-06-24", 
# 				"plot_csv_folder/abi_delay_50.csv", "plot_csv_folder/abi_thrpt_50.csv", "plot_csv_folder/abi_loss_50.csv")


bar_csv_gen("log/GEA_SHR_8000_15", "log/GEA_WP_8000_15", "log/GEA_QoS_8000_15", 
				"drl-or/log/GEA-15-6000", 
				"maddpg_pareto/log/GEA-origin-15-[0.05, 0.03, 0.03, 0.05]-False-1-2-uniDemand-False-100-myuti-50-6000", 
				"maddpg_pareto/log_evaluate/GEA-pareto-15-[0.25, 0.25, 0.25, 0.25]-0.005-0.005-True-1-2-9-uniDemand-False-0.95-30-5e-05-0.9-5000-01-reward-for-evaluate", 
				"plot_csv_folder/gea_delay_15.csv", "plot_csv_folder/gea_thrpt_15.csv", "plot_csv_folder/gea_loss_15.csv")

bar_csv_gen("log/GEA_SHR_8000_50", "log/GEA_WP_8000_50", "log/GEA_QoS_8000_50", 
				"drl-or/log/GEA-50-6000", 
				"maddpg_pareto/log/GEA-origin-50-[0.05, 0.05, 0.05, 0.05]-5e-05-5e-05-True-1-2-8-uniDemand-False-0.99-30-5e-05-0.98-1000-01-reward", 
				"maddpg_pareto/log_evaluate/GEA-pareto-50-[0.05, 0.05, 0.05, 0.05]-5e-05-5e-05-True-1-2-9-uniDemand-False-0.99-30-5e-05-0.98-1001-01-reward-for-evaluate-2021-06-01", 
				"plot_csv_folder/gea_delay_50.csv", "plot_csv_folder/gea_thrpt_50.csv", "plot_csv_folder/gea_loss_50.csv")


i = 0
topo_name = "abi"
for metric_name, metric_col in zip(["delay", "loss", "thrpt"], ["Delay", "Loss Ratio", "Thrpt Ratio"]):
    for load, title in zip([10, 30, 50], ["low", "middle", "high"]):
        plt.figure(i)
        plot_matric_cmp(topo_name, metric_name, str(load), metric_col, title)
        i += 1

topo_name = "gea"
for metric_name, metric_col in zip(["delay", "loss", "thrpt"], ["Delay", "Loss Ratio", "Thrpt Ratio"]):
    for load, title in zip([15, 50], ["low", "high"]):
        plt.figure(i)
        plot_matric_cmp(topo_name, metric_name, str(load), metric_col, title)
        i += 1