#!/bin/bash
echo ""
echo "                Clean mininet!!!"
echo ""
sudo mn -c
# for((i=1;i<=100;i++)) 
# do sudo lsof -i:5000 | awk '{print $2}' | awk 'NR==2{print}' | xargs kill -9; done


i=1
while(($i<=100))
do
	echo $i
	sudo lsof -i:5000 | awk '{print $2}' | awk 'NR==2{print}' | xargs kill -9; 
	let "i++"
done

echo ""
echo "                start testbed!!!"
echo ""
# sudo python testbed.py Abi
sudo python testbed.py GEA
