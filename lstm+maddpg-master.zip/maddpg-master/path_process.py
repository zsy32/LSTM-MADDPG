
# file_name = "drl-or/log/GEA/path.log"

# file_name = "maddpg_pareto/log/Abi-pareto-50-[2.5, 2.5, 2.5, 2.5]-5e-05-5e-05-True-1-3-uniDemand-False-0.99-30-5e-05-0.98-1000-only-delay-test-noTarget/path.log"

def get_path_set(file_name):
    file = open(file_name, "r")
    s_t_path = {}


    for line in file.readlines():
        x = line[1:-2]
        x = x.split(',')
        x = [int(a) for a in x]

        s = x[0]
        t = x[-1]
        key = str(s) + "-" + str(t)
        if key in s_t_path.keys():
            if str(x) in s_t_path[key]:
                s_t_path[key][str(x)] += 1
            else:
                s_t_path[key][str(x)] = 1
        else:
            s_t_path[key] = dict()
            s_t_path[key][str(x)] = 1
        # print(key, ", ", x)
    # print(s_t_path)

    max_len = 0
    check_sum = 0
    for key in sorted(s_t_path):
        max_len = max(max_len, len(s_t_path[key]))

        sub_keys = list(s_t_path[key].keys())
        for sub_key in sub_keys:
            check_sum += s_t_path[key][sub_key]
            if s_t_path[key][sub_key] < 5:
                del s_t_path[key][sub_key]
    # print(max_len)
    # print(check_sum)

    path_set = set()
    for key in sorted(s_t_path):
        # print(key, ", ", s_t_path[key])
        for sub_key in s_t_path[key].keys():
            path_set.add(sub_key)

    return path_set


thu_paths    = get_path_set("drl-or/log/abi/path.log")
pareto_paths = get_path_set("maddpg_pareto/log/Abi-pareto-50-[0.05, 0.05, 0.05, 0.05]-5e-05-5e-05-True-1-2-uniDemand-False-0.99-30-5e-05-0.98-1000-continuous-reward/path.log")

# thu_paths    = get_path_set("drl-or/log/GEA/path.log")
# pareto_paths = get_path_set("maddpg_pareto/log/GEA-pareto-50-[0.05, 0.05, 0.05, 0.05]-5e-05-5e-05-True-1-2-uniDemand-False-0.99-30-5e-05-0.98-1000-seed1 (veli veli nicer)/path.log")



print("paths of thu methods: {}".format(len(thu_paths)))
print("paths of our methods: {}".format(len(pareto_paths)))
print("paths of intersection: {}".format(len(thu_paths & pareto_paths)))
print()
print(thu_paths - pareto_paths)
print()
print(pareto_paths - thu_paths)


# import pickle

# f = open("abi_path.pkl", "wb")
# pickle.dump(s_t_path, f)

# f = open("abi_path.pkl", "rb")
# x = pickle.load(f)
# temp = (x['2-10'])

# print(temp)
# for i in range(len(temp.keys())):
#     k = list(temp.keys())[i]
#     print(k)
#     x = k[1:-1]
#     x = x.split(',')
#     x = [int(a) for a in x]
#     print(x)
    

