import torch
import os
from policy_low.actor_critic_low import Actor_Low, Critic_Low


class DDPG:
    def __init__(self, args, agent_id):  # 因为不同的agent的obs、act维度可能不一样，所以神经网络不同,需要agent_id来区分
        self.args = args
        self.agent_id = agent_id
        self.train_step = 0

        # create the network
        self.actor_network  = Actor_Low(args, agent_id)
        self.critic_network = Critic_Low(args)

        # build up the target network
        self.actor_target_network  = Actor_Low(args, agent_id)
        self.critic_target_network = Critic_Low(args)

        # load the weights into the target networks
        self.actor_target_network.load_state_dict(self.actor_network.state_dict())
        self.critic_target_network.load_state_dict(self.critic_network.state_dict())

        # create the optimizer
        self.actor_optim  = torch.optim.Adam(self.actor_network.parameters(),  lr=self.args.lr_low_actor)
        self.critic_optim = torch.optim.Adam(self.critic_network.parameters(), lr=self.args.lr_low_critic)

        # create the dict for store the model
        if not os.path.exists(self.args.save_dir):
            os.mkdir(self.args.save_dir)
        # path to save the model
        self.model_path = self.args.save_dir + '/' + self.args.scenario_name
        if not os.path.exists(self.model_path):
            os.mkdir(self.model_path)
        self.model_path = self.model_path + '/' + 'agent_%d' % agent_id
        if not os.path.exists(self.model_path):
            os.mkdir(self.model_path)

        # 加载模型
        if os.path.exists(self.model_path + '/actor_params.pkl'):
            self.actor_network.load_state_dict(torch.load(self.model_path + '/actor_params.pkl'))
            self.critic_network.load_state_dict(torch.load(self.model_path + '/critic_params.pkl'))
            print('Agent {} successfully loaded actor_network:  {}'.format(self.agent_id, self.model_path + '/actor_params.pkl'))
            print('Agent {} successfully loaded critic_network: {}'.format(self.agent_id, self.model_path + '/critic_params.pkl'))

    # soft update
    def _soft_update_target_network(self):
        for target_param, param in zip(self.actor_target_network.parameters(), self.actor_network.parameters()):
            target_param.data.copy_((1 - self.args.tau) * target_param.data + self.args.tau * param.data)

        for target_param, param in zip(self.critic_target_network.parameters(), self.critic_network.parameters()):
            target_param.data.copy_((1 - self.args.tau) * target_param.data + self.args.tau * param.data)

    # update the network
    def train(self, transitions):
        print("Lower-level DDPG of Single Agent {}".format(self.agent_id), self.train_step)

        for key in transitions.keys():
            transitions[key] = torch.tensor(transitions[key], dtype=torch.float32)
          # 训练时只需要自己的reward

        o, u, o_next = [], [], []  # 用来装每个agent经验中的各项

        o = transitions['o']
        u = transitions['u']
        r = transitions['r']
        o_next = transitions['o_next']


        u_next = []
        with torch.no_grad():
            # 得到下一个状态对应的动作
            u_next = ( self.actor_target_network(o_next) )
            
            q_next = self.critic_target_network(o_next, u_next).detach()

            target_q = (r.unsqueeze(1) + self.args.gamma * q_next).detach()

        q_value = self.critic_network(o, u)
        critic_loss = (target_q - q_value).pow(2).mean()

        u = self.actor_network(o)
        actor_loss       = - self.critic_network(o, u).mean()

        self.actor_optim.zero_grad()
        actor_loss.backward()

        self.actor_optim.step()
        
        self.critic_optim.zero_grad()
        critic_loss.backward()
        self.critic_optim.step()

        self._soft_update_target_network()
        if self.train_step > 0 and self.train_step % self.args.save_rate == 0:
            self.save_model(self.train_step)
        self.train_step += 1


    def save_model(self, train_step):
        num = str(train_step // self.args.save_rate)
        model_path = os.path.join(self.args.save_dir, self.args.scenario_name)
        if not os.path.exists(model_path):
            os.makedirs(model_path)
        model_path = os.path.join(model_path, 'agent_%d' % self.agent_id)
        if not os.path.exists(model_path):
            os.makedirs(model_path)
        torch.save(self.actor_network.state_dict(), model_path + '/' + num + '_lower_actor_params.pkl')
        torch.save(self.critic_network.state_dict(),  model_path + '/' + num + '_lower_critic_params.pkl')


