import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F


class Actor_Low(nn.Module):
    def __init__(self, args, agent_id):
        super(Actor_Low, self).__init__()
        self.args = args

        self.input1 = nn.Linear(self.args.feature_per_path, self.args.feature_per_path)
        self.input2 = nn.Linear(self.args.feature_per_path, self.args.feature_per_path)
        
        self.fc1 = nn.Linear(self.args.feature_per_path, 1)
        self.fc2 = nn.Linear(self.args.feature_per_path, 1)

        self.follow_fc = nn.Linear(2, 2)


    def forward(self, x):
        p1 = x[0][0 : self.args.feature_per_path].unsqueeze(0)
        p2 = x[0][1 * self.args.feature_per_path : 2 * self.args.feature_per_path].unsqueeze(0)

        x1 = F.sigmoid(self.fc1(self.input1(p1)))
        x2 = F.sigmoid(self.fc2(self.input2(p2)))

        concat = torch.cat((x1, x2), 1)
        final = self.follow_fc(concat)
        actions = F.softmax(final)

        return actions


class Critic_Low(nn.Module):
    def __init__(self, args):
        super(Critic_Low, self).__init__()
        self.args = args
        
        self.input_o = nn.Linear(self.args.num_paths * self.args.feature_per_path + self.args.node_num, 4)
        self.input_a = nn.Linear(2, 2)
        self.q_out = nn.Linear(6, 1)

    def forward(self, state, action):
        x = self.input_o(state)
        a = self.input_a(action)

        final = torch.cat((x, a), 1)
        q_value = self.q_out(final)

        return q_value
