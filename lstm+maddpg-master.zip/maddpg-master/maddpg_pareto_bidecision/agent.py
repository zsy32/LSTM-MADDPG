import os
import torch

import numpy as np

# from maddpg.maddpg import MADDPG
from policy_high.maddpg import MADDPG
from policy_low.ddpg import DDPG


class Agent_High:
    def __init__(self, agent_id, args):
        self.args     = args
        self.agent_id = agent_id
        self.policy = MADDPG(args, agent_id)

    def select_action(self, o, noise_rate, epsilon):
        if np.random.uniform() < epsilon:
            #u = np.random.randint(0, self.args.action_shape[self.agent_id])
            u = np.random.uniform(0, 1, self.args.high_action_shape[self.agent_id])
            u = np.array(u)
            u = torch.tensor([u])
            # print("have explore")
            # print(u)
            # print(type(u))
        else:
            inputs = torch.tensor(o, dtype=torch.float32).unsqueeze(0)
            u = self.policy.actor_network(inputs)

            # for name, param in self.policy.actor_network.named_parameters():
            #     if name == "follow_fc.weight" and self.agent_id == 0:
            #         print(name)
            #         print(param)

            
            # pi = self.policy.actor_network(inputs).squeeze(0)
            # print('{} : {}'.format(self.name, pi))
            # u = pi.cpu().numpy()
            # noise = noise_rate * self.args.high_action * np.random.randn(*u.shape)  # gaussian noise
            # u += noise
            # u = np.clip(u, -self.args.high_action, self.args.high_action)
        return u
    
    def select_action_eval(self, o, noise_rate, epsilon):
        if np.random.uniform() < epsilon:
            #u = np.random.randint(0, self.args.action_shape[self.agent_id])
            u = np.random.uniform(0, 1, self.args.action_shape[self.agent_id])
            u = np.array(u)
            u = torch.tensor([u])
            # print("have explore")
            # print(u)
            # print(type(u))
        else:
            inputs = torch.tensor(o, dtype=torch.float32).unsqueeze(0)
            u = self.policy.actor_network(inputs)

            # for name, param in self.policy.actor_network.named_parameters():
            #     if name == "follow_fc.weight":
            #         print(name)
            #         print(param)

            
            # pi = self.policy.actor_network(inputs).squeeze(0)
            # print('{} : {}'.format(self.name, pi))
            # u = pi.cpu().numpy()
            # noise = noise_rate * self.args.high_action * np.random.randn(*u.shape)  # gaussian noise
            # u += noise
            # u = np.clip(u, -self.args.high_action, self.args.high_action)
        return u

    def learn(self, transitions, other_agents):
        self.policy.train(transitions, other_agents)

    def pareto_learn(self, transitions, other_agents, global_critic, target_global_critic, gCritic_optim):
        self.policy.pareto_train(transitions, other_agents, global_critic, target_global_critic, gCritic_optim)


class Agent_Low:
    def __init__(self, agent_id, args):
        self.args     = args
        self.agent_id = agent_id
        self.policy = DDPG(args, agent_id)

    def select_action(self, o, noise_rate, epsilon):
        if np.random.uniform() < epsilon:
            #u = np.random.randint(0, self.args.action_shape[self.agent_id])
            u = np.random.uniform(0, 1, self.args.action_shape[self.agent_id])
            u = np.array(u)
            u = torch.tensor([u])
            # print("have explore")
            # print(u)
            # print(type(u))
        else:
            inputs = torch.tensor(o, dtype=torch.float32).unsqueeze(0)
            u = self.policy.actor_network(inputs)

            # for name, param in self.policy.actor_network.named_parameters():
            #     if name == "follow_fc.weight" and self.agent_id == 0:
            #         print(name)
            #         print(param)

            
            # pi = self.policy.actor_network(inputs).squeeze(0)
            # print('{} : {}'.format(self.name, pi))
            # u = pi.cpu().numpy()
            # noise = noise_rate * self.args.high_action * np.random.randn(*u.shape)  # gaussian noise
            # u += noise
            # u = np.clip(u, -self.args.high_action, self.args.high_action)
        return u
    
    def select_action_eval(self, o, noise_rate, epsilon):
        if np.random.uniform() < epsilon:
            #u = np.random.randint(0, self.args.action_shape[self.agent_id])
            u = np.random.uniform(0, 1, self.args.action_shape[self.agent_id])
            u = np.array(u)
            u = torch.tensor([u])
            # print("have explore")
            # print(u)
            # print(type(u))
        else:
            inputs = torch.tensor(o, dtype=torch.float32).unsqueeze(0)
            u = self.policy.actor_network(inputs)

            # for name, param in self.policy.actor_network.named_parameters():
            #     if name == "follow_fc.weight":
            #         print(name)
            #         print(param)

            
            # pi = self.policy.actor_network(inputs).squeeze(0)
            # print('{} : {}'.format(self.name, pi))
            # u = pi.cpu().numpy()
            # noise = noise_rate * self.args.high_action * np.random.randn(*u.shape)  # gaussian noise
            # u += noise
            # u = np.clip(u, -self.args.high_action, self.args.high_action)
        return u

    def learn(self, transitions):
        self.policy.train(transitions)
