import argparse
import torch
import datetime
"""
Here are the param for the training

"""


def get_args():
    parser = argparse.ArgumentParser("Reinforcement Learning experiments for multiagent environments")
    # Environment

    parser.add_argument("--max-episode-len", type=int, default=10000, help="maximum episode length")

    # 一个地图最多env.n个agents，用户可以定义min(env.n,num-adversaries)个敌人，剩下的是好的agent
    parser.add_argument("--n_agents",        type=int, default=4, help="number of agents")

    # Core training parameters
    parser.add_argument("--buffer-size", type=int, default=int(5e5), help="number of transitions can be stored in buffer")
    parser.add_argument("--batch-size",  type=int, default=1, help="number of episodes to optimize at the same time")
    # Checkpointing
    parser.add_argument("--model-dir", type=str, default="", help="directory in which training state and model are loaded")

    # Evaluate
    parser.add_argument("--evaluate-episodes",    type=int, default=10, help="number of episodes for evaluating")
    parser.add_argument("--evaluate-episode-len", type=int, default=100, help="length of episodes for evaluating")
    parser.add_argument("--evaluate",      type=bool, default=False, help="whether to evaluate the model")
    parser.add_argument("--evaluate-rate", type=int, default=1000, help="how often to evaluate model")
    

    # previous args
    parser.add_argument('--no-cuda',  action='store_true', default=False, help='disables CUDA training')
    # running config
    """
    parser.add_argument('--seed', type=int, default=1, help='random seed (default: 1)')
    parser.add_argument('--cuda-deterministic', action='store_true', default=False, help="sets flags for determinism when using CUDA (potentially slow!)")
    
    parser.add_argument('--num-steps', type=int, default=512, help='number of forward steps (default: 512) i.e.num-step for each update epoch')
    parser.add_argument('--num-pretrain-epochs', type=int, default=30, help='number of pretraining steps  (default: 500)')
    parser.add_argument('--num-pretrain-steps', type=int, default=128, help='number of forward steps for pretraining (default: 128)')
    
    parser.add_argument('--ckpt-steps',    type=int, default=10000, help='number of iteration steps for each checkpoint when training')
    parser.add_argument('--num-env-steps', type=int, default=10000000, help='number of environment steps to train (default: 1000000)')
    
    
    parser.add_argument('--log-dir',  default='/tmp/DRL-OR', help='directory to save agent logs (default: /tmp/DRL-OR)')
    #parser.add_argument('--save-dir', default='./trained_models/', help='directory to save agent logs (default: ./trained_models/)')
    
    
    parser.add_argument("--model-load-path", default=None, help='load model parameters from the model-load-path')
    parser.add_argument("--model-save-path", default=None, help='save model parameters at the model-save-path')


    parser.add_argument('--algo', default='ppo', help='algorithm to use: a2c | ppo')
    parser.add_argument('--lr', type=float, default=2.5e-5, help='learning rate (default: 2.5e-5)')
    parser.add_argument('--eps', type=float, default=1e-5, help='RMSprop optimizer epsilon (default: 1e-5)')
    parser.add_argument('--alpha', type=float, default=0.99, help='RMSprop optimizer apha (default: 0.99)')
    #parser.add_argument('--gamma', type=float, default=0.99, help='discount factor for rewards (default: 0.99)')
    parser.add_argument('--use-gae', action='store_true', default=False, help='use generalized advantage estimation')
    parser.add_argument('--gae-lambda', type=float, default=0.95, help='gae lambda parameter (default: 0.95)')
    parser.add_argument('--entropy-coef', type=float, default=0.01, help='entropy term coefficient (default: 0.01)')
    parser.add_argument('--value-loss-coef', type=float, default=0.5, help='value loss coefficient (default: 0.5)')
    parser.add_argument('--max-grad-norm', type=float, default=0.5, help='max norm of gradients (default: 0.5)')
    parser.add_argument('--ppo-epoch', type=int, default=4, help='number of ppo epochs (default: 4)')
    parser.add_argument('--num-mini-batch', type=int, default=32, help='number of batches for ppo (default: 32)')
    parser.add_argument('--clip-param', type=float, default=0.1, help='ppo clip parameter (default: 0.1)')
    parser.add_argument('--recurrent-policy', action='store_true', default=False, help='use a recurrent policy')
    parser.add_argument('--use-linear-lr-decay', action='store_true', default=False, help='use a linear schedule on the learning rate')
    parser.add_argument('--use-linear-clip-decay', action='store_true', default=False, help='use a linear schedule on the ppo clipping parameter')
    """
    # parser.add_argument("--time_steps",      type=int, default=6000, help="number of time steps")
    # parser.add_argument('--env-name', default='Abi', help='environment to train on (default: Abi)') #temporarily deprecated
    # parser.add_argument("--demand-matrix", default='test.txt', help='demand matrix input file name (default:test.txt)')
    # parser.add_argument("--scenario_name", type=str, default="MARL-RoutingGEA", help="name of the scenario script")
    parser.add_argument("--save-dir",  type=str, default="./han_model", help="directory in which training state and model should be saved")
    parser.add_argument("--save-rate", type=int, default=100, help="save model once every time this many episodes are completed")
    
    parser.add_argument("--lr_high_actor",   type=float, default=5e-3, help="learning rate of high_actor")
    parser.add_argument("--lr_high_critic",  type=float, default=5e-3, help="learning rate of high_critic")
    parser.add_argument("--lr_low_actor",   type=float, default=5e-3, help="learning rate of low_actor")
    parser.add_argument("--lr_low_critic",  type=float, default=5e-3, help="learning rate of low_critic")
    parser.add_argument("--epsilon",    type=float, default=0.1, help="epsilon greedy")
    parser.add_argument("--noise_rate", type=float, default=0.1, help="noise rate for sampling from a standard normal distribution ")
    parser.add_argument("--gamma",      type=float, default=0.95, help="discount factor")
    parser.add_argument("--tau",        type=float, default=0.01, help="parameter for updating the target network")

    args = parser.parse_args()

    args.cuda = not args.no_cuda and torch.cuda.is_available()

    args.k         = 1
    args.num_paths = 2
    args.feature_per_path = 9

    args.time_steps    = 20011
    args.env_name      = "GEA" # Abi | GEA
    args.scenario_name = "MARL-Routing" + args.env_name
    args.reward_type   = "continuous"  # Abi continuous | GEA discrete
    args.demand_matrix = "{}_500.txt".format(args.env_name)

    args.node_num     = 23 # Abi 11 , GEA 23
    args.obs_shape    = [ (args.feature_per_path * args.num_paths + args.node_num) for i in range(4)]
    args.action_shape = [args.num_paths for i in range(4)]
    args.high_action_shape = [1 for i in range(4)]

    args.critic_input_size = 4
    args.critic_state_shape = [args.critic_input_size for i in range(4)]

    # veli veli nicer [0.05, 0.03, 0.03, 0.05] for Abi
    # args.global_critic_reward_weight = [0.05, 0.05, 0.05, 0.05]
    args.global_critic_reward_weight = [0.25, 0.25, 0.25, 0.25]

    args.load = 50
    args.request_times = [[args.load], [args.load], [args.load], [args.load]] # heavy load
    args.my_request_times = int(args.load / 4) # 30 / 4 = 7 , 50 / 4 = 12, 10 / 4 = 2 Abi | 15 / 4 = 3 GEA

    args.grad_method = "pareto"
    # args.grad_method = "origin"

    args.reverse_alpha = True
    args.alpha = 0.98

    args.uniDemand = False
    # args.Demand_val = 100

    args.thr_ratio_base = 0.99 #0.95
    args.delay_base = 30 #45
    args.loss_base  = 0.00005 #0.005

    args.MyUtili = "myuti"

    args.today = str(datetime.date.today())


    args.log_dir = "log/" + args.env_name + \
                            "-" + args.grad_method + \
                            "-" + str(args.request_times[0][0]) + \
                            "-" + str(args.global_critic_reward_weight) + \
                            "-" + str(args.lr_high_actor) + "-" + str(args.lr_high_critic) + \
                            "-" + str(args.lr_low_actor) + "-" + str(args.lr_low_critic) + \
                            "-" + str(args.reverse_alpha)+  \
                            "-" + str(args.k) + "-" + str(args.num_paths) + "-" + str(args.feature_per_path) + \
                            "-" + "uniDemand" + "-" + str(args.uniDemand) + \
                            "-" + str(args.thr_ratio_base) + "-" + str(args.delay_base) + "-" + str(args.loss_base) + \
                            "-" + str(args.alpha) + \
                            "-" + str(args.time_steps) + "-" + args.reward_type + "-reward-" + args.today


    args.log_dir_eval = "log_evaluate/" + args.env_name + \
                            "-" + args.grad_method + \
                            "-" + str(args.request_times[0][0]) + \
                            "-" + str(args.global_critic_reward_weight) + \
                            "-" + str(args.lr_high_actor) + "-" + str(args.lr_high_critic) + \
                            "-" + str(args.lr_low_actor) + "-" + str(args.lr_low_critic) + \
                            "-" + str(args.reverse_alpha)+  \
                            "-" + str(args.k) + "-" + str(args.num_paths) + "-" + str(args.feature_per_path) + \
                            "-" + "uniDemand" + "-" + str(args.uniDemand) + \
                            "-" + str(args.thr_ratio_base) + "-" + str(args.delay_base) + "-" + str(args.loss_base) + \
                            "-" + str(args.alpha) + \
                            "-" + str(args.time_steps) + "-" + args.reward_type + "-reward-for-evaluate-" + args.today
    

    return args
