import networkx as nx


G = nx.DiGraph()

# G.add_edge(1, 2, weight=1)
# G.add_edge(2, 4, weight=1)
# G.add_edge(4, 5, weight=1)
# G.add_edge(1, 5, weight=9)

G.add_edge(1, 2)
G.add_edge(2, 4)
G.add_edge(4, 5)
G.add_edge(1, 5)

print(nx.dijkstra_path(G, 1, 5))

for u, v, d in G.edges(data=True):
    if u==1 and v==5:
        d['weight'] = 9

print(nx.dijkstra_path(G, 1, 5))