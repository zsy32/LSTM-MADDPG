import numpy as np
import matplotlib.pyplot as plt  

dir_name = "maddpg_pareto_bidecision_slice/log/GEA-15-20011-2021-12-16 21:18:40.612785"
dir_name = "maddpg_pareto/log/GEA-maddpg-pareto-50-2001-2021-12-21 17:19:47.533325"
dir_name = "maddpg_pareto/log/GEA-maddpg-pareto-50-40001-2021-12-21 20:48:52.479156"

file_name_1 = dir_name + "/reward_type0.log"
file_name_2 = dir_name + "/reward_type1.log"
file_name_3 = dir_name + "/reward_type2.log"
file_name_4 = dir_name + "/reward_type3.log"


def return_w(file_name_1):
	f1 = open(file_name_1, "r")
	lines = f1.readlines()
	x = []
	w1 = []

	for i, line in enumerate(lines):
		lien = float(line.strip())
		if i % 1 == 0:
			x.append(i)
			w1.append(lien)

	# max_1 = max(w1)
	# min_1 = min(w1)

	# w1 = [(x - min_1)/(max_1 - min_1) for x in w1]
	return x, w1

x, w1 = return_w(file_name_1)
print(len(x), len(w1))
x, w2 = return_w(file_name_2)
print(len(x), len(w2))
x, w3 = return_w(file_name_3)
print(len(x), len(w3))
x, w4 = return_w(file_name_4)
print(len(x), len(w4))

min_len = len(w1)
min_len = 10000
min_len = min(min_len, len(w2))
min_len = min(min_len, len(w3))
min_len = min(min_len, len(w4))

x = x[:min_len]
w1 = w1[:min_len]
w2 = w2[:min_len]
w3 = w3[:min_len]
w4 = w4[:min_len]


l1 = plt.plot(x,w1,"r-",label = "type1")
l2 = plt.plot(x,w2,"g-",label = "type2")
l3 = plt.plot(x,w3,"b-",label = "type3")
l4 = plt.plot(x,w4,"y-",label = "type4")

plt.plot(x,w1,"r-",x,w2,"g-",x,w3,"b-", x,w4,"y-")


plt.title("The Lasers in Three Conditions")

plt.xlabel("Step")
plt.ylabel("Reward")
plt.legend()

plt.savefig("reward.png")