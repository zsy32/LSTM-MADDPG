import numpy as np
import matplotlib.pyplot as plt  
import seaborn as sn
import pandas as pd 


def get_avg_val(file_name):
    f = open(file_name, "r")
    y = f.readlines()
    y = [a.strip() for a in y]
    y = [float(a) for a in y]

    val = round(sum(y) / len(y), 2)
    print(val)
    # print("{}\t{}\t{}".format(term_name, str(val), type_name), file = csv_file)

    return val


def bar_csv_gen(metric_name, topo_name, load, shr_dir, wp_dir, qos_dir, drl_or_dir, maddpg_dir, bimar_dir):
    delay_list = []
    for i in range(4):
        temp_list = []
        temp_list.append(get_avg_val(shr_dir + "/{}_type{}.log".format(metric_name, i)))
        temp_list.append(get_avg_val(wp_dir + "/{}_type{}.log".format(metric_name, i)))
        temp_list.append(get_avg_val(qos_dir + "/{}_type{}.log".format(metric_name, i)))
        temp_list.append(get_avg_val(drl_or_dir + "/{}_type{}.log".format(metric_name, i)))
        temp_list.append(get_avg_val(maddpg_dir + "/{}_type{}.log".format(metric_name, i)))
        temp_list.append(get_avg_val(bimar_dir + "/{}_type{}.log".format(metric_name, i)))

        delay_list.append(temp_list)
    
    df_cm = pd.DataFrame(delay_list)
    print(df_cm)
    df_new = df_cm.rename(columns={0:'SHR', 1:'WP', 2:'COMA', 3:'DRL-OR', 4:'MADPG', 5:'Bi_MAR'}, 
                            index={0: 'Intent\ntype 1', 1: 'Intent\ntype 2',2: 'Intent\ntype 3',3: 'Intent\ntype 4'})
    print(df_new)
    svm = sn.heatmap(df_new, annot=True,cmap='RdBu_r', linecolor='white', linewidths=0, fmt ='.4')

    svm.invert_yaxis()
    # plt.title("{} comparison".format(metric_name))
    plt.title("{} comparison under {} load in {}".format(metric_name, load, topo_name))

    plt.xlabel("Method")
    plt.ylabel("Intent Type")
    plt.yticks(rotation=0)

    # plt.savefig("Delay.png")
    plt.savefig("plot_csv_folder/img/{}_{}_{}.png".format(topo_name, load, metric_name))

i = 0
for metric_name in ['delay', 'loss', 'throughput']:
    i += 1
    plt.figure(i)
    bar_csv_gen(metric_name, "Abilene", 10,
                "paper/shr/Abi_SHR_8000_10", 
                "paper/wp/Abi_WP_8000_10", 
                "paper/coma/Abi-coma-10-2001-2021-12-17 15:06:14.147270", #"paper/qos/Abi_QoS_8000_10", 
                "paper/drl/abi-10-2000", 
                "paper/maddpg/myabi-origin-10-2000", 
                "paper/bimar/Abi-pareto-10-[0.05, 0.05, 0.05, 0.05]-5e-05-5e-05-True-1-2-9-uniDemand-False-0.99-30-5e-05-0.98-1001-01-reward-for-evaluate-2021-06-01", )