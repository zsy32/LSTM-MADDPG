#!/bin/bash
# i=1
# while true:
# do
# 	echo $i

# 	x=$(sudo lsof -i:5000 | awk '{print $2}' | awk 'NR==2{print}' )

# 	if !x
# 	then
# 		echo "no process at port 5000, stop killing"
# 		break
# 	else
# 	sudo lsof -i:5000 | awk '{print $2}' | awk 'NR==2{print}' | xargs kill -9; 
# 	fi
# 	let "i++"
# done
echo ""
echo "                Clean mininet!!!"
echo ""
sudo mn -c

#for((i=1;i<=100;i++)) do sudo lsof -i:5000 | awk '{print $2}' | awk 'NR==2{print}' | sudo xargs kill -9; done


i=1
while(($i<=300))
do
	echo $i
	sudo lsof -i:5000 | awk '{print $2}' | awk 'NR==2{print}' | xargs kill -9; 
	let "i++"
done

echo ""
echo "                start testbed!!!"
echo ""
#sudo python testbed.py test
# sudo python testbed.py Abi
sudo python testbed.py GEA
