import numpy as np
import matplotlib.pyplot as plt  

file_name = "maddpg_pareto_bidecision_slice/log/GEA-15-20011-2021-12-16 20:28:15.291413/weight.log"
# file_name = "maddpg_pareto_bidecision_slice/log/GEA-15-20011-2021-12-16 20:49:40.792134/weight.log"
# file_name = "maddpg_pareto_bidecision_slice/log/GEA-15-20011-2021-12-16 21:18:40.612785/weight.log"

file_name = "maddpg_pareto_bidecision_slice/log/GEA-15-20011-2021-12-18 15:29:42.578137/weight.log"
file_name = "maddpg_pareto_bidecision_slice/log/GEA-15-2000-2021-12-18 16:00:28.943420/weight.log"

f = open(file_name, "r")

n = 8
# lines = f.readlines()[n*2798 : (n+1)*2798]
lines = f.readlines()

x = []
w1 = []
w2 = []
w3 = []
w4 = []

for i, line in enumerate(lines):
    lien = (line[1:-2]).split(",")
    if i % 17 == 0:
        x.append(i)
        w1.append(float(lien[0].strip()))
        w2.append(float(lien[1].strip()))
        w3.append(float(lien[2].strip()))
        w4.append(float(lien[3].strip()))



l1 = plt.plot(x,w1,"r-",label = "type1")
l2 = plt.plot(x,w2,"g-",label = "type2")
l3 = plt.plot(x,w3,"b-",label = "type3")
l4 = plt.plot(x,w4,"y-",label = "type4")
# plt.plot(x,w1,"ro-",x,w2,"g+-",x,w3,"b^-", x,w4,"y--")

# plt.plot(x,w1,"r-")
plt.plot(x,w1,"r-",x,w2,"g-",x,w3,"b-", x,w4,"y-")


plt.title("Weight Distribution among Flows of Four Intent Type")
plt.ylim(0.15, 0.35) 
plt.xlabel("Step")
plt.ylabel("Weight Percent")
plt.legend()

plt.savefig("weight.png")