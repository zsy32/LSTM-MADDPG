import numpy as np
import matplotlib.pyplot as plt  
import seaborn as sn
import pandas as pd 

file_name = "maddpg_pareto_bidecision_slice/net_env/st_file_GEA.txt"

f = open(file_name, "r")
lines = f.readlines()

import collections
# initializing deque
de = collections.deque([])

x = []
w1 = []
w2 = []
w3 = []
w4 = []

all_b = 0
b1 = 0
b2 = 0
b3 = 0
b4 = 0
band_type_dict = {0 : b1, 1: b2, 2: b3, 3: b4}

b_dict = {0 : 100, 1: 1500, 2: 1500, 3: 500}

final_array = []

j = 0
for i, line in enumerate(lines):
    lien = line.split(",")
    type_i = int(lien[-1])

    if i < 50:
        de.append([type_i])
        all_b += b_dict[type_i]
        band_type_dict[type_i] += b_dict[type_i]
    else:
        temp_list = []
        pop_type = de.popleft()[0]
        print(pop_type)
        all_b -= b_dict[pop_type]
        band_type_dict[pop_type] -= b_dict[pop_type]

        de.append([type_i])
        all_b += b_dict[type_i]
        band_type_dict[type_i] += b_dict[type_i]

        print(len(de))

        # x.append(j)
        if i % 100 == 0:
            temp_list.append(band_type_dict[0] / all_b)
            temp_list.append(band_type_dict[1] / all_b)
            temp_list.append(band_type_dict[2] / all_b)
            temp_list.append(band_type_dict[3] / all_b)
            final_array.append(temp_list)

        # w1.append(band_type_dict[0] / all_b)
        # w2.append(band_type_dict[1] / all_b)
        # w3.append(band_type_dict[2] / all_b)
        # w4.append(band_type_dict[3] / all_b)
        # j += 1

df_cm = pd.DataFrame(final_array)
df_cm = df_cm.transpose()
svm = sn.heatmap(df_cm, annot=False,cmap='RdBu_r', linecolor='white', linewidths=0)

svm.invert_yaxis()
plt.title("Heatmap of flows weight")

plt.xlabel("Step")
plt.ylabel("Weight Percent")

plt.savefig("weight_heat.png")