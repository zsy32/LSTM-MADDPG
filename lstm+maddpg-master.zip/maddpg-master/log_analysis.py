import numpy as np
import matplotlib.pyplot as plt


# def plot_file(file1_name, file2_name):
# 	if file1_name:
# 		file1 = open(file1_name, "r")
# 		y = file1.readlines()
# 		y = [a.strip() for a in y]
# 		y = [float(a) for a in y]
# 		x = []
# 		for i in range(len(y)):
# 			x.append(i)
# 		# plt.plot(x, y, 'r.')
# 		cnt_print(y)
# 		print("{} {:2f}".format("Thu Method: " , sum(y) / len(y)))

# 	if file2_name:
# 		file2 = open(file2_name, "r")
# 		y = file2.readlines()
# 		y = [a.strip() for a in y]
# 		y = [float(a) for a in y]
# 		# y = y[:l]
# 		x = []
# 		for i in range(len(y)):
# 			x.append(i)
# 		# plt.plot(x, y, 'g.')
# 		cnt_print(y)
# 		print("{} {:2f}".format("Our Method: " , sum(y) / len(y)))
# 	plt.show()
	

def print_file(file1_name, file2_name):
	if file1_name:
		file1 = open(file1_name, "r")
		y = file1.readlines()
		y = [a.strip() for a in y]
		y = [float(a) for a in y]

		x = []
		if len(y) > 0 :
			for i in range(len(y)):
				x.append(i)
			print("{} {:2f}".format("Thu Method: " , sum(y) / len(y)))
		else:
			print("{} {:2f}".format("Thu Method: " , sum(y) / 1))

	if file2_name:
		file2 = open(file2_name, "r")
		y = file2.readlines()
		y = [a.strip() for a in y]
		y = [float(a) for a in y]
		# y = y[220:]

		x = []
		if len(y) > 0 :
			for i in range(len(y)):
				x.append(i)
			print("{} {:2f}".format("Our Method: " , sum(y) / len(y)))
		else:
			print("{} {:2f}".format("Our Method: " , sum(y) / 1))
		# print("Currently, {} data".format(len(y)))

def cnt_print(y):
	cnt_100 = 0
	cnt_500 = 0
	cnt_more = 0
	for i in y:
		if i < 100:
			cnt_100 += 1
		elif i < 500:
			cnt_500 += 1
		else:
			cnt_more += 1
	print("{:2f}, {:2f}, {:2f}, {:2f}".format(cnt_100 / len(y), cnt_500 / len(y), cnt_more / len(y), sum(y) / len(y)))



"""

# GEA
thu_name = "drl-or/log/GEA-50-6000"
thu_name = "drl-or/log/GEA-test"
thu_name = "drl-or_slice/log/GEA_slice"
# thu_name = "log/GEA_QoS_8000_50"
# thu_name  = "maddpg_pareto/log/GEA-pareto-50-[0.25, 0.25, 0.25, 0.25]-0.005-0.005-True-1-2-9-uniDemand-False-0.99-30-5e-05-0.9-10000-01-reward"
my_name  = "maddpg_pareto/log/GEA-pareto-50-[0.25, 0.25, 0.25, 0.25]-0.005-0.005-True-1-2-9-uniDemand-False-0.99-30-5e-05-0.9-10000-01-reward-one_hot"

my_name = "maddpg_step/log/GEA-pareto-50-[0.25, 0.25, 0.25, 0.25]-1e-05-1e-05-True-0-1-uniDemand-False-0.99-30-5e-05-0.98-4000-only-delay-test-seed2-noTarget"
my_name = "maddpg_pareto/log_evaluate/GEA-pareto-15-[0.25, 0.25, 0.25, 0.25]-0.005-0.005-True-1-2-9-uniDemand-False-0.95-30-5e-05-0.9-5000-01-reward-for-evaluate"

# thu_name = "maddpg_pareto/log_evaluate/GEA-pareto-50-[0.25, 0.25, 0.25, 0.25]-0.005-0.005-True-1-2-9-uniDemand-False-0.95-30-5e-05-0.9-5000-01-reward-for-evaluate"
my_name = "maddpg_pareto/log_evaluate/GEA-pareto-50-[0.05, 0.05, 0.05, 0.05]-5e-05-5e-05-True-1-2-9-uniDemand-False-0.99-30-5e-05-0.98-1001-01-reward-for-evaluate-2021-06-01"
my_name = "maddpg_pareto/log_evaluate/GEA-pareto-50-[0.05, 0.05, 0.05, 0.05]-5e-05-5e-05-True-1-2-9-uniDemand-False-0.99-30-5e-05-0.98-5001-continuous-reward-for-evaluate-2021-06-04"

my_name = "maddpg_pareto_bidecision_slice/log/GEA-pareto-15-[0.25, 0.25, 0.25, 0.25]-0.005-0.005-0.005-0.005-True-1-2-9-uniDemand-False-0.99-30-5e-05-0.98-1011-continuous-reward-2021-07-03 21:27:01.646409"

my_name = "maddpg_pareto_bidecision_slice/log/GEA-pareto-50-[0.25, 0.25, 0.25, 0.25]-0.005-0.005-0.005-0.005-True-1-2-9-uniDemand-False-0.99-30-0.01-0.98-10011-continuous-reward-2021-07-05 19:02:53.198409"
my_name = "maddpg_pareto_bidecision_slice/log/GEA-pareto-50-[0.25, 0.25, 0.25, 0.25]-0.005-0.005-0.005-0.005-True-1-2-9-uniDemand-False-0.99-30-0.01-0.98-10011-continuous-reward-2021-07-08 13:06:24.630570"
my_name = "maddpg_pareto_bidecision_slice/log/GEA-pareto-50-[0.25, 0.25, 0.25, 0.25]-0.005-0.005-0.005-0.005-True-1-2-9-uniDemand-False-0.99-30-0.01-0.98-10011-continuous-reward-2021-07-08 17:49:00.542529"
my_name = "maddpg_pareto_bidecision_slice/log/GEA-pareto-200-[0.25, 0.25, 0.25, 0.25]-0.005-0.005-0.005-0.005-True-1-2-9-uniDemand-False-0.99-30-0.01-0.98-10011-continuous-reward-2021-07-08 19:51:58.373992"

my_name = "maddpg_pareto_bidecision_slice/log/GEA-pareto-50-[0.25, 0.25, 0.25, 0.25]-0.005-0.005-0.005-0.005-True-1-2-9-uniDemand-False-0.99-30-0.01-0.98-10011-continuous-reward-2021-07-08 23:26:30.067403"

my_name = "maddpg_pareto_bidecision_slice/log/GEA-pareto-50-[0.25, 0.25, 0.25, 0.25]-0.005-0.005-0.005-0.005-True-1-2-9-uniDemand-False-0.99-30-0.01-0.98-10011-continuous-reward-2021-07-09 09:52:25.453759"
my_name = "maddpg_pareto_bidecision_slice/log/GEA-pareto-50-[0.25, 0.25, 0.25, 0.25]-0.005-0.005-0.005-0.005-True-1-2-9-uniDemand-False-0.99-30-0.01-0.98-10011-continuous-reward-2021-07-09 10:27:06.173273"

my_name = "maddpg_pareto_bidecision_slice/log/GEA-pareto-50-[0.25, 0.25, 0.25, 0.25]-0.005-0.005-0.005-0.005-True-1-2-9-uniDemand-False-0.99-30-0.01-0.98-10011-continuous-reward-2021-07-09 10:49:59.269982"
my_name = "maddpg_pareto_bidecision_slice/log/GEA-pareto-50-[0.25, 0.25, 0.25, 0.25]-0.005-0.005-0.005-0.005-True-1-2-9-uniDemand-False-0.99-30-0.01-0.98-10011-continuous-reward-2021-07-09 11:13:39.733267-[0.01, 0.37, 0.37, 0.25]"

my_name = "maddpg_pareto_bidecision_slice/log/GEA-pareto-50-[0.25, 0.25, 0.25, 0.25]-0.005-0.005-0.005-0.005-True-1-2-9-uniDemand-False-0.99-30-0.01-0.98-10011-continuous-reward-2021-07-09 11:26:00.907828-[0.02, 0.39, 0.39, 0.2]"
my_name = "maddpg_pareto_bidecision_slice/log/GEA-pareto-50-[0.25, 0.25, 0.25, 0.25]-0.005-0.005-0.005-0.005-True-1-2-9-uniDemand-False-0.99-30-0.01-0.98-10011-continuous-reward-2021-07-13 22:38:09.819667-[0.02, 0.39, 0.39, 0.2]"
my_name = "maddpg_pareto_bidecision_slice/log/GEA-pareto-50-[0.25, 0.25, 0.25, 0.25]-0.005-0.005-0.005-0.005-True-1-2-9-uniDemand-False-0.99-30-0.01-0.98-10011-continuous-reward-2021-07-18 16:03:30.039218-[0.02, 0.39, 0.39, 0.2]"
# my_name = "maddpg_pareto_bidecision_slice/log/GEA-pareto-50-[0.25, 0.25, 0.25, 0.25]-0.005-0.005-0.005-0.005-True-1-2-9-uniDemand-False-0.99-30-0.01-0.98-10011-continuous-reward-2021-07-16 16:06:36.676918-[0.02, 0.39, 0.39, 0.2]"
my_name = "maddpg_pareto_bidecision_slice/log/GEA-pareto-50-[0.25, 0.25, 0.25, 0.25]-0.005-0.005-0.005-0.005-True-1-2-9-uniDemand-False-0.99-30-0.01-0.98-20011-continuous-reward-2021-07-20 23:56:26.438627-[0.02, 0.39, 0.39, 0.2]"

my_name = "maddpg_pareto_bidecision_slice/log_evaluate/GEA-pareto-50-[0.25, 0.25, 0.25, 0.25]-0.005-0.005-0.005-0.005-True-1-2-9-uniDemand-False-0.99-30-0.01-0.98-20011-continuous-reward-for-evaluate-2021-07-22 19:39:39.810411"

"""

thu_name = "paper/bimar/Abi-pareto-50-[0.05, 0.05, 0.05, 0.05]-5e-05-5e-05-True-1-2-9-uniDemand-False-0.99-30-5e-05-0.98-1001-continuous-reward-for-evaluate-2021-06-03-4model"
my_name = "maddpg_pareto/log/Abi-coma-50-2001-2021-12-17 15:44:09.716357"

thu_name = "paper/bimar/GEA-pareto-15-[0.25, 0.25, 0.25, 0.25]-0.005-0.005-True-1-2-9-uniDemand-False-0.95-30-5e-05-0.9-5000-01-reward-for-evaluate"
my_name = "maddpg_pareto/log/GEA-maddpg-origin-15-2001-2021-12-17 20:15:44.739447"

print(thu_name + " Vs " + my_name)

print("\t\tAverage Delay")

for i in range(4):
	# if i == 1:
		# continue
	print("Flow Type: {}".format(i))
	print_file(thu_name + "/delay_type%d.log" % (i), my_name + "/delay_type%d.log" % (i))
	print()

print("\t\tAverage Throughput Satisfaction")

for i in range(4):
	# if i == 0 or i == 3:
		# continue
	print("Flow Type: {}".format(i))
	print_file(thu_name + "/throughput_type%d.log" % (i), my_name + "/throughput_type%d.log" % (i))
	print()

print("\t\tAverage Loss Ratio")

for i in range(4):
	# if i != 3:
		# continue
	print("Flow Type: {}".format(i))
	print_file(thu_name + "/loss_type%d.log" % (i), my_name + "/loss_type%d.log" % (i))
	print()
	
