# running PPO
#python3 main.py --use-gae --num-mini-batch 4 --use-linear-lr-decay --num-env-steps 10000000 --env-name test --log-dir ./log/test --demand-matrix Abi_500.txt --model-save-path ./model/test 

# python3 main.py --use-gae --num-mini-batch 4 --use-linear-lr-decay --num-env-steps 10000000 --env-name Abi --log-dir ./log/abi --demand-matrix Abi_500.txt --model-save-path ./model/test 
# python3 net_env/simenv.py 
python3 main.py --use-gae --num-mini-batch 4 --use-linear-lr-decay --num-env-steps 10000000 --env-name GEA --log-dir ./log/GEA_slice --demand-matrix GEA_500.txt --model-save-path ./model/GEA 


#python3 main.py --use-gae --num-mini-batch 4 --use-linear-lr-decay --num-env-steps 10000000 --env-name Abi --log-dir ./log/test --demand-matrix Abi_500.txt --model-save-path ./model/test 


