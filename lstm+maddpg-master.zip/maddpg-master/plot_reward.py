import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

def plot_file(file1_name):
	if file1_name:
		file1 = open(file1_name, "r")

		y = file1.readlines()
		y = [a.strip() for a in y]
		y = [float(a) for a in y]

		y = y[3840:]
		print(len(y))

		x = []
		y1 = []
		y2 = []
		y3 = []
		y4 = []
		for i in range(len(y)):
			if i % 4 == 0:
				y1.append(y[i])
			elif i % 4 == 1:
				y2.append(y[i])
			elif i % 4 == 2:
				y3.append(y[i])
			elif i % 4 == 3:
				y4.append(y[i])


		for i in range(int(len(y) / 4)):
			x.append(i)

		plt.plot(x, y1, 'r--')
		plt.plot(x, y2, 'g--')
		plt.plot(x, y3, 'b--')
		plt.plot(x, y4, 'y--')

	plt.savefig("line-thu.png")



def plot_files(files):
	token = ['r--', 'g--', 'b--', 'y--']
	for file_name, t in zip(files, token):
		f = open(file_name, "r")
		y = f.readlines()
		y = [a.strip() for a in y]
		y = [float(a) for a in y]
		x = []
		for i in range(int(len(y))):
			x.append(i)
			
		plt.plot(x, y, t)

	plt.savefig("line-my.png")


def reward_4(file1_name, files):
	file1 = open(file1_name, "r")

	y = file1.readlines()
	y = [a.strip() for a in y]
	y = [float(a) for a in y]
	y = y[3840:]
	print(len(y))

	x = []
	thu_y = []
	y1 = []
	y2 = []
	y3 = []
	y4 = []
	for i in range(len(y)):
		if i % 4 == 0:
			y1.append(y[i])
		elif i % 4 == 1:
			y2.append(y[i])
		elif i % 4 == 2:
			y3.append(y[i])
		elif i % 4 == 3:
			y4.append(y[i])

	for i in range(int(len(y) / 4)):
		x.append(i)
	thu_y.append(y1)
	thu_y.append(y2)
	thu_y.append(y3)
	thu_y.append(y4)

	token = [0, 1, 2, 3]
	for t_y, file_name, type_num in zip(thu_y, files, token):
		f = open(file_name, "r")
		y = f.readlines()
		y = [a.strip() for a in y]
		y = [float(a)  for a in y]
		x = []
		for i in range(int(len(y))):
			x.append(i)
		
		# df = pd.DataFrame()
		# df['x'] = x
		# df['my_y'] = y
		# df['th_y'] = t_y
		# sns.lineplot(data=df)
		# plt.show()
		plt.figure(type_num)
		plt.plot(x, t_y, 'r--')
		plt.plot(x, y,   'b--')
		plt.savefig("type_{}.png".format(type_num))



def reward_3src(files_thu, files_ori, files_pare):
	token = [0, 1, 2, 3]
	for thu_f, ori_f, pare_f, type_num in zip(files_thu, files_ori, files_pare, token):
		cur_files = []
		cur_files.append(thu_f)
		cur_files.append(ori_f)
		cur_files.append(pare_f)

		print("type-",type_num, " reward variance")
		for file_name, t, l in zip(cur_files, ["r--", "b--", "g--"], ["drl-or", "maddpg", "our method"]):
			f = open(file_name, "r")
			y = f.readlines()
			y = [a.strip() for a in y]
			y = [float(a)  for a in y]
			x = []

			
			print("{}: {:.2f}".format(l, np.var(y)))

			for i in range(int(len(y))):
				x.append(i)
			
			plt.figure(type_num)
			plt.plot(x, y, t, label=l)
		plt.legend()
		plt.savefig("type_{}.png".format(type_num))

def reward_1src(files_pare):
	token = [0, 1, 2, 3]
	for pare_f, type_num in zip(files_pare, token):
		cur_files = []
		cur_files.append(pare_f)

		print("type-",type_num, " reward variance")
		for file_name, t, l in zip(cur_files, ["g."], ["our method"]):
			f = open(file_name, "r")
			y = f.readlines()
			y = [a.strip() for a in y]
			y = [float(a)  for a in y]
			x = []
			# print("{}: {:.2f}".format(l, np.var(y)))

			# for i in range(int(len(y))):
			# 	if y[i] > 100:
			# 		y[i] = 100

			for i in range(int(len(y))):
				x.append(i)
			
			plt.figure(type_num)
			plt.plot(x, y, t, label=l)

		plt.legend()
		plt.savefig("type_{}.png".format(type_num))

file_name = "drl-or/log/abi-50-2000/globalrwd.log"
plot_file(file_name)

# dir_name_thu    = "drl-or/log/GEA-15-6000"
# dir_name_origin = "maddpg_pareto/log/GEA-origin-15-[0.05, 0.03, 0.03, 0.05]-False-1-2-uniDemand-False-100-myuti-50-6000"
# dir_name_pareto = "maddpg_pareto_bidecision/log_evaluate/Abi-pareto-50-[0.05, 0.05, 0.05, 0.05]-5e-05-5e-05-True-1-2-9-uniDemand-False-0.99-30-5e-05-0.98-1001-continuous-reward-for-evaluate-2021-06-24"

# files_thu    = []
# files_origin = []
# files_pareto = []

# metric_name = "delay"

# for i in range(4):
# 	files_thu.append(dir_name_thu       + "/{}_type{}.log".format(metric_name, i))
# 	files_origin.append(dir_name_origin + "/{}_type{}.log".format(metric_name, i))
# 	files_pareto.append(dir_name_pareto + "/{}_type{}.log".format(metric_name, i))

# reward_1src(files_pareto)

# reward_3src(files_thu, files_origin, files_pareto)
