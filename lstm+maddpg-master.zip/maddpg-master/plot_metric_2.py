import pandas as pd
import matplotlib.pyplot as plt

img_file_dir = "plot_csv_folder_0923"
date_str = "10_16"

def bar_csv_gen(shr_dir, wp_dir, qos_dir, drl_or_dir, maddpg_dir, maddpg_pareto_dir, target_delay_name, target_thrpt_name, target_loss_name):
	bar_csv_file = open(target_delay_name, "w")
	print("Method\tDelay\tFlow Type", file = bar_csv_file)
	# print("Delay")
	for i in range(4):
		get_avg_val(shr_dir + "/delay_type%d.log" % (i), bar_csv_file, "shr type%d" % (i), "Flow type%d Delay" % (i))
		get_avg_val(wp_dir  + "/delay_type%d.log" % (i), bar_csv_file, "wp type%d" % (i), "Flow type%d Delay" % (i))
		get_avg_val(qos_dir + "/delay_type%d.log" % (i), bar_csv_file, "qos type%d" % (i), "Flow type%d Delay" % (i))
		get_avg_val(drl_or_dir + "/delay_type%d.log" % (i), bar_csv_file, "drl-or type%d" % (i), "Flow type%d Delay" % (i))
		# get_avg_val(maddpg_dir + "/delay_type%d.log" % (i), bar_csv_file, "maddpg type%d" % (i), "Flow type%d Delay" % (i))
		get_avg_val(maddpg_dir + "/delay_type%d.log" % (i), bar_csv_file, "coma type%d" % (i), "Flow type%d Delay" % (i))
		get_avg_val(maddpg_pareto_dir + "/delay_type%d.log" % (i), bar_csv_file, "Our type%d" % (i), "Flow type%d Delay" % (i))
	bar_csv_file.close()


	bar_csv_file = open(target_thrpt_name, "w")
	print("Method\tThrpt Ratio\tFlow Type", file = bar_csv_file)
	# print("Thrpt Ratio")
	for i in range(4):
		get_avg_val_thr(shr_dir + "/throughput_type%d.log" % (i), bar_csv_file, "shr type%d" % (i), "Flow type%d Thrpt ratio" % (i))
		get_avg_val_thr(wp_dir  + "/throughput_type%d.log" % (i), bar_csv_file, "wp type%d" % (i), "Flow type%d Thrpt ratio" % (i))
		get_avg_val_thr(qos_dir + "/throughput_type%d.log" % (i), bar_csv_file, "qos type%d" % (i), "Flow type%d Thrpt ratio" % (i))
		get_avg_val_thr(drl_or_dir + "/throughput_type%d.log" % (i), bar_csv_file, "drl-or type%d" % (i), "Flow type%d Thrpt ratio" % (i))
		# get_avg_val_thr(maddpg_dir + "/throughput_type%d.log" % (i), bar_csv_file, "maddpg type%d" % (i), "Flow type%d Thrpt ratio" % (i))
		get_avg_val_thr(maddpg_dir + "/throughput_type%d.log" % (i), bar_csv_file, "coma type%d" % (i), "Flow type%d Thrpt ratio" % (i))
		get_avg_val_thr(maddpg_pareto_dir + "/throughput_type%d.log" % (i), bar_csv_file, "Our type%d" % (i), "Flow type%d Thrpt ratio" % (i))
	bar_csv_file.close()


	bar_csv_file = open(target_loss_name, "w")
	print("Method\tLoss Ratio\tFlow Type", file = bar_csv_file)
	# print("Loss Ratio")
	for i in range(4):
		get_avg_val(shr_dir + "/loss_type%d.log" % (i), bar_csv_file, "shr type%d" % (i), "Flow type%d Loss ratio" % (i))
		get_avg_val(wp_dir  + "/loss_type%d.log" % (i), bar_csv_file, "wp type%d" % (i), "Flow type%d Loss ratio" % (i))
		get_avg_val(qos_dir + "/loss_type%d.log" % (i), bar_csv_file, "qos type%d" % (i), "Flow type%d Loss ratio" % (i))
		get_avg_val(drl_or_dir + "/loss_type%d.log" % (i), bar_csv_file, "drl-or type%d" % (i), "Flow type%d Loss ratio" % (i))
		# get_avg_val(maddpg_dir + "/loss_type%d.log" % (i), bar_csv_file, "maddpg type%d" % (i), "Flow type%d Loss ratio" % (i))
		get_avg_val(maddpg_dir + "/loss_type%d.log" % (i), bar_csv_file, "coma type%d" % (i), "Flow type%d Loss ratio" % (i))
		get_avg_val(maddpg_pareto_dir + "/loss_type%d.log" % (i), bar_csv_file, "Our type%d" % (i), "Flow type%d Loss ratio" % (i))
	bar_csv_file.close()


def get_avg_val(file_name, csv_file, term_name, type_name):
	f = open(file_name, "r")
	y = f.readlines()
	y = [a.strip() for a in y]
	y = [float(a) for a in y]
	if len(y) == 0:
		val = 0
	else:
		val = sum(y) / len(y)

	# print(val)
	print("{}\t{}\t{}".format(term_name, str(val), type_name), file = csv_file)

def get_avg_val_thr(file_name, csv_file, term_name, type_name):
	f = open(file_name, "r")
	y = f.readlines()
	y = [a.strip() for a in y]
	y = [float(a) for a in y]
	if len(y) == 0:
		val = 0
	else:
		val = sum(y) / len(y)

	if val > 1.0:
		val = 1.0
	# print(val)
	print("{}\t{}\t{}".format(term_name, str(val), type_name), file = csv_file)

def plot_matric_cmp(topo_name, metric_name, load, metric_col, title, testcase):
    data = pd.read_csv(img_file_dir + "/{}_{}_{}_{}.csv".format(topo_name, metric_name, load, testcase), sep='\t')
    # converting column data to list
    methods = data['Method'].tolist()
    method = [x.split()[0] for x in methods]

    x = list(range(len(method)))
    # sort the metric by flow type in the chart as ['Flow type0 Delay', 'Flow type1 Delay', 'Flow type2 Delay', 'Flow type3 Delay']
    flow_type = set(data['Flow Type'].tolist())
    flow_type = sorted(flow_type)

    l_idx = 0
    r_idx = 0
    for type_name in flow_type:
        delay  = data[data['Flow Type'] == type_name][metric_col].tolist()
        r_idx = l_idx + len (delay)
        new_x = x[l_idx : r_idx]
        # print(new_x)
        # print(delay)
        # for i in range(len(delay)):
        #     if metric_name == "thrpt" and delay[i] > 1.0:
        #         delay[i] = 1.0
        plt.bar(new_x, delay, label = type_name.split()[1])
        l_idx = r_idx
    #柱子上的数字显示
    x_text = x
    delay_text = data[metric_col].tolist()
    for a,b in zip(x, delay_text):   
        plt.text(a, b, '%.2f'%b, ha='center', va='bottom', fontsize=6)
    plt.xticks(x, method, rotation=85)
    plt.xlabel("Method")
    plt.ylabel("Average {}".format(metric_col))
    plt.legend(bbox_to_anchor=(1.04,1), loc="upper left")
    plt.title("{} comparison under {} load in {} (testcase {})".format(metric_col, title, topo_name, testcase))
    plt.tight_layout()
    plt.savefig(img_file_dir + "/img/{}_{}_{}_{}.png".format(topo_name, load, metric_name, testcase))



# bar_csv_gen("log/Abi_SHR_8000_50", "log/Abi_WP_8000_50", "log/Abi_QoS_8000_50", 
# 				"drl-or/log/abi-50-2000", 
# 				"maddpg_pareto/log/myabi-origin-50-2000", 
# 				"maddpg_pareto_bidecision/log_evaluate/Abi-pareto-50-[0.05, 0.05, 0.05, 0.05]-5e-05-5e-05-True-1-2-9-uniDemand-False-0.99-30-5e-05-0.98-1001-continuous-reward-for-evaluate-2021-06-24", 
# 				"plot_csv_folder/abi_delay_50.csv", "plot_csv_folder/abi_thrpt_50.csv", "plot_csv_folder/abi_loss_50.csv")


# bar_csv_gen("", "", "", 
# 				"result/drl/log-1/GEA-test", 
# 				"", 
# 				"result/maddpg/log_evaluate-1/GEA-pareto-50-[0.25, 0.25, 0.25, 0.25]-0.005-0.005-0.005-0.005-True-1-2-9-uniDemand-False-0.99-30-0.01-0.98-2000-continuous-reward-for-evaluate-2021-08-04 12_33_02.872777", 
# 				img_file_dir + "/gea_delay_50_1.csv", 
# 				img_file_dir + "/gea_thrpt_50_1.csv", 
# 				img_file_dir + "/gea_loss_50_1.csv")

# bar_csv_gen("", "", "", 
# 				"result/drl/log-3/GEA-test", 
# 				"", 
# 				"result/maddpg/log_evaluate-3/GEA-pareto-50-[0.25, 0.25, 0.25, 0.25]-0.005-0.005-0.005-0.005-True-1-2-9-uniDemand-False-0.99-30-0.01-0.98-2000-continuous-reward-for-evaluate-2021-08-04 16_15_04.968901", 
# 				img_file_dir + "/gea_delay_50_3.csv", 
# 				img_file_dir + "/gea_thrpt_50_3.csv", 
# 				img_file_dir + "/gea_loss_50_3.csv")

# bar_csv_gen("log/GEA_SHR_8000_50_simenv_heavyload_1-5loss", "log/GEA_WP_8000_50_simenv_heavyload_1-5loss", "log/GEA_QoS_8000_50_simenv_heavyload_1-5loss", 
# 				"drl-or-origin/log/GEA-test-final-1", 
# 				"", 
# 				"maddpg_pareto_bidecision_slice/log_evaluate/GEA-pareto-50-for-evaluate-2021-09-08 15:54:34.985988",
# 				img_file_dir + "/gea_delay_50_8_30.csv", 
# 				img_file_dir + "/gea_thrpt_50_8_30.csv", 
# 				img_file_dir + "/gea_loss_50_8_30.csv")

# bar_csv_gen("log/GEA_SHR_8000_15_simenv_heavyload_1-5loss", "log/GEA_WP_8000_15_simenv_heavyload_1-5loss", "log/GEA_QoS_8000_15_simenv_heavyload_1-5loss", 
# 				"drl-or-origin/log/GEA-test-final-15", 
# 				"", 
# 				"maddpg_pareto_bidecision_slice/log_evaluate/GEA-pareto-15-[0.25, 0.25, 0.25, 0.25]-0.005-0.005-0.005-0.005-True-1-2-9-uniDemand-False-0.99-30-0.01-0.98-20011-continuous-reward-for-evaluate-2021-09-15 21:16:08.035913",
# 				img_file_dir + "/gea_delay_15_8_30.csv", 
# 				img_file_dir + "/gea_thrpt_15_8_30.csv", 
# 				img_file_dir + "/gea_loss_15_8_30.csv")


bar_csv_gen("log/GEA_SHR_8000_15", "log/GEA_WP_8000_15", "log/GEA_QoS_8000_15", 
				"drl-or/log/GEA-15-6000", 
				"maddpg_pareto/log/GEA-coma-15-10001-2021-10-14 18:31:48.587612", 
				"maddpg_pareto/log_evaluate/GEA-pareto-15-[0.25, 0.25, 0.25, 0.25]-0.005-0.005-True-1-2-9-uniDemand-False-0.95-30-5e-05-0.9-5000-01-reward-for-evaluate",
				img_file_dir + "/gea_delay_15_{}.csv".format(date_str), 
				img_file_dir + "/gea_thrpt_15_{}.csv".format(date_str), 
				img_file_dir + "/gea_loss_15_{}.csv".format(date_str))

i = 0
# topo_name = "abi"
# for metric_name, metric_col in zip(["delay", "loss", "thrpt"], ["Delay", "Loss Ratio", "Thrpt Ratio"]):
#     for load, title in zip([10, 30, 50], ["low", "middle", "high"]):
#         plt.figure(i)
#         plot_matric_cmp(topo_name, metric_name, str(load), metric_col, title)
#         i += 1

topo_name = "gea"
for metric_name, metric_col in zip(["delay", "loss", "thrpt"], ["Delay", "Loss Ratio", "Thrpt Ratio"]):
	for load, title in zip([15], ["low"]):
		for testcase in [date_str]:
			plt.figure(i)
			plot_matric_cmp(topo_name, metric_name, str(load), metric_col, title, testcase)
			i += 1
