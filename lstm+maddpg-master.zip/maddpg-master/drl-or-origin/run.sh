# running PPO
python3 main.py --use-gae --num-mini-batch 4 --use-linear-lr-decay --num-env-steps 10000000 --env-name GEA --log-dir ./log/GEA-test-final-15 --demand-matrix GEA_500.txt --model-save-path ./model/test 

# python3 net_env/simenv.py 
