import os
import torch

import numpy as np

# from maddpg.maddpg import MADDPG
from maddpg_pareto.maddpg import MADDPG


class Agent:
    def __init__(self, agent_id, args):
        self.args     = args
        self.agent_id = agent_id
        self.policy = MADDPG(args, agent_id)

    def select_action(self, o, noise_rate, epsilon):
        if np.random.uniform() < epsilon:
            #u = np.random.randint(0, self.args.action_shape[self.agent_id])
            u = np.random.uniform(0, 1, self.args.action_shape[self.agent_id])
            u = np.array(u)
            u = torch.tensor([u])
            # print("have explore")
            # print(u)
            # print(type(u))
        else:
            inputs = torch.tensor(o, dtype=torch.float32).unsqueeze(0)
            u = self.policy.actor_network(inputs)
            # print("no explore")
            # print(u)
            # print(type(u))
            
            # pi = self.policy.actor_network(inputs).squeeze(0)
            # print('{} : {}'.format(self.name, pi))
            # u = pi.cpu().numpy()
            # noise = noise_rate * self.args.high_action * np.random.randn(*u.shape)  # gaussian noise
            # u += noise
            # u = np.clip(u, -self.args.high_action, self.args.high_action)
        return u

    def learn(self, transitions, other_agents):
        self.policy.train(transitions, other_agents)

    def pareto_learn(self, transitions, other_agents, global_critic, target_global_critic, gCritic_optim):
        self.policy.pareto_train(transitions, other_agents, global_critic, target_global_critic, gCritic_optim)

