import os
import time
import torch

import numpy as np
import matplotlib.pyplot as plt

from tqdm  import tqdm

from agent import Agent
from common.replay_buffer       import Buffer

from maddpg_pareto.actor_critic import gCritic


class Runner:
    def __init__(self, args, env):
        self.args    = args
        self.noise   = args.noise_rate

        self.env    = env
        self.agents = self._init_agents()
        self.buffer = Buffer(args)

        self.global_critic = gCritic(args)
        self.target_global_critic = gCritic(args)
        self.gCritic_optim = torch.optim.Adam(self.global_critic.parameters(), lr=self.args.lr_critic)

        self.epsilon       = args.epsilon
        self.episode_limit = args.max_episode_len
        
        self.save_path = self.args.save_dir + '/' + self.args.scenario_name
        if not os.path.exists(self.save_path):
            os.makedirs(self.save_path)

        self.grad_method = self.args.grad_method
        print("Initial time for each request: {}".format(self.args.my_request_times))
        self.log_delay_files      = []
        self.log_throughput_files = []
        self.log_loss_files       = []
        self.log_reward_files     = []

        log_dir = self.args.log_dir
        os.makedirs(log_dir)
        for i in range(4):
            log_delay_file      = open("%s/delay_type%d.log" % (log_dir, i), "w", 1)
            self.log_delay_files.append(log_delay_file)

            log_throughput_file = open("%s/throughput_type%d.log" % (log_dir, i), "w", 1)
            self.log_throughput_files.append(log_throughput_file)

            log_loss_file       = open("%s/loss_type%d.log" % (log_dir, i), "w", 1)
            self.log_loss_files.append(log_loss_file)

            log_reward_file     = open("%s/reward_type%d.log" % (log_dir, i), "w", 1)
            self.log_reward_files.append(log_reward_file)


    def _init_agents(self):
        agents = []
        for i in range(self.args.n_agents):
            agent = Agent(i, self.args)
            agents.append(agent)
        return agents


    def run(self):
        returns = []
        action_history = {}
        action_history["agent0"] = [0, 0 ,0]
        action_history["agent1"] = [0, 0 ,0]
        action_history["agent2"] = [0, 0 ,0]
        action_history["agent3"] = [0, 0 ,0]

        for time_step in tqdm(range(self.args.time_steps)):
            if time_step % self.episode_limit == 0:
                s = self.env.han_reset()

            u = []
            actions = []
            
            with torch.no_grad():
                for agent_id, agent in enumerate(self.agents):
                    action = agent.select_action(s[agent_id], self.noise, self.epsilon)
                    
                    u.append(action)
                    actions.append(action.argmax().numpy())

                    action_history["agent{}".format(agent_id)][action.argmax().numpy()] += 1

            s_next, r = self.env.han_step(actions, self.log_delay_files, self.log_throughput_files, self.log_loss_files, self.log_reward_files)

            self.buffer.store_episode(s, u, r, s_next)
            s = s_next

            # print("simulating...", time_step)
            if self.buffer.current_size >= self.args.batch_size:
                transitions = self.buffer.sample(self.args.batch_size)

                for agent in self.agents:
                    other_agents = self.agents.copy()
                    other_agents.remove(agent)

                    if self.grad_method == "origin":
                        agent.learn(transitions, other_agents)
                    elif self.grad_method == "pareto":
                        # agent.pareto_learn(transitions, other_agents, self.global_critic, self.gCritic_optim)
                        agent.pareto_learn(transitions, other_agents, self.global_critic, self.target_global_critic, self.gCritic_optim)
                    
            # self.noise   = max(0.05, self.noise - 0.0000005)
            self.epsilon = max(0.005, self.epsilon - 0.0005)
            #np.save(self.save_path + '/returns.pkl', returns)
        print(action_history)

    def evaluate(self):
        returns = []
        for episode in range(self.args.evaluate_episodes):
            # reset the environment
            s = self.env.reset()
            rewards = 0
            for time_step in range(self.args.evaluate_episode_len):
                self.env.render()
                actions = []
                with torch.no_grad():
                    for agent_id, agent in enumerate(self.agents):
                        action = agent.select_action(s[agent_id], 0, 0)
                        actions.append(action)
                for i in range(self.args.n_agents, self.args.n_players):
                    actions.append([0, np.random.rand() * 2 - 1, 0, np.random.rand() * 2 - 1, 0])
                s_next, r, done, info = self.env.step(actions)
                rewards += r[0]
                s = s_next
            returns.append(rewards)
            print('Returns is', rewards)
        return sum(returns) / self.args.evaluate_episodes
