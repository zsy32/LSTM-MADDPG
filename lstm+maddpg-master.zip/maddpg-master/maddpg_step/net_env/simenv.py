'''
author: lcy
This file provides the python interfaces of the routers simulations environment
this file do the interactions between ryu+mininet
'''
from gym import spaces
if __name__ == "__main__":
    from utils import weight_choice
else:
    from net_env.utils import weight_choice
import torch
import random
import numpy as np
import os
import sys
import glob
import heapq
import copy
import json
import socket
import argparse
import time

import matplotlib.pyplot as plt
import networkx as nx

class Request():
    def __init__(self, s, t, start_time, end_time, demand, rtype):
        # use open time interval: start_time <= time < end_time
        self.s = s
        self.t = t
        self.start_time = start_time
        self.end_time   = end_time
        self.demand     = demand
        self.rtype      = rtype
    '''
        deprecated function
    '''
    def to_json(self):
        data = {
            'src':    int(self.s),
            'dst':    int(self.t),
            'time':   int(self.end_time - self.start_time),
            'rtype':  int(self.rtype),
            'demand': int(self.demand),
                }
        return json.dumps(data)

    
    def __lt__(self, other):
        return self.end_time < other.end_time
    
    def __str__(self):
        return "s: %d t: %d\nstart_time: %d\nend_time: %d\ndemand: %d\nrtype: %d" % (self.s, self.t, self.start_time, self.end_time, self.demand, self.rtype)

class NetEnv():
    '''
    must run setup before using other methods
    '''
    def __init__(self, args):
        self.args = args
        self.port = 10000

        self._observation_spaces = []
        self._action_spaces      = []

        self._delay_discounted_factor = 0.99
        self._loss_discounted_factor  = 0.99

        self.BUFFER_SIZE  = 1024
        # set up communication to remote hosts(mininet host)
        MININET_HOST_IP   = '127.0.0.1' # Testbed server IP
        MININET_HOST_PORT = 5000
        self.mininet_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.mininet_socket.connect((MININET_HOST_IP, MININET_HOST_PORT))
        
        CONTROLLER_IP = '127.0.0.1'
        CONTROLLER_PORT = 3999
        self.controller_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.controller_socket.connect((CONTROLLER_IP, CONTROLLER_PORT))

        self.k = args.k
        self.num_paths = args.num_paths
        self.total_demand = 0
        self.my_request_times = args.my_request_times
        self.default_state = [0 for i in range (8 * args.num_paths + args.node_num)]


    @property
    def observation_spaces(self):
        return self._observation_spaces
    
    @property
    def action_spaces(self):
        return self._action_spaces

    '''
    @param:
        toponame: a string indicate the toponame for the environment
    @retval:
        node_num: an int
        observation_spaces: a [node_name] shape list shows the observation spaces for each node, now are Box(k)
        action_spaces: a [node_name] shape list shows the observation spaces for each node, now are Discrete(l)
    '''
    def setup(self, toponame, demand_matrix_name):
        self._time_step = 0
        self._request_heapq = []

        # init DiffServ info
        self._type_num = 4
        self._type_dist = np.array([0.2, 0.3, 0.3, 0.2]) # TO BE CHECKED BEFORE EXPERIMENT

        # load topo info(direct paragraph)
        if toponame == "test":
            self._node_num = 4
            self._edge_num = 8

            self._observation_spaces = []
            self._action_spaces      = []
            # topology info
            self._link_lists  = [[3, 1], [0, 2], [1, 3], [2, 0]]
            self._shr_dist    = [[0, 1, 2, 1], [1, 0, 1, 2], [2, 1, 0, 1], [1, 2, 1, 0]]
            self._link_capa   = [[0, 1000, 0, 5000], [1000, 0, 5000, 0], [0, 5000, 0, 5000], [5000, 0, 5000, 0]] # link capacity (Kbps)
            self._link_usage  = [[0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]] # usage of link capacity
            self._link_losses = [[0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]] # link losses, x% x is int
            # request generating setting
            # bandwidth aware usually need as large bandwidth as they can, delay-bandwidth aware may have several stage of bandwidth demand
            self._request_demands = [[100], [500], [500], [100]]   
            self._request_times   = [[10], [10], [10], [10]] # simple example test
            self._node_to_agent   = [0, 1, 2, 3]# i:None means drl-agent not deploys on node i; i:j means drl-agent j deploys on node i
            self._agent_to_node   = [0, 1, 2, 3] # indicate the ith agent's node
            self._agent_num     = 4
            self._demand_matrix = [0, 1, 1, 1,
                                   1, 0, 1, 1,
                                   1, 1, 0, 1,
                                   1, 1, 1, 0]

            for i in self._agent_to_node:
                # onehot src, onehot dst, neighbour shr dist to each node
                # low and high for Box isn't essential
                self._observation_spaces.append(spaces.Box(0., 1., [1 + self._node_num * len(self._link_lists[i]) + self._node_num * len(self._link_lists[i]) + self._node_num ** 2 + self._node_num ** 2 + self._type_num + self._node_num * 2], dtype=np.float32)) # maximum observation space
                #self._observation_spaces.append(spaces.Box(0., 1., [1 + len(self._link_lists[i]) + len(self._link_lists[i]) + self._type_num + self._node_num * 2], dtype=np.float32)) # minimum observation space
                self._action_spaces.append(spaces.Discrete(2))
            
        elif toponame == "Abi":
            self._load_topology(toponame, demand_matrix_name)
        elif toponame == "GEA":
            self._load_topology(toponame, demand_matrix_name)
        else:
            raise NotImplementedError
        return self._agent_num, self._node_num, self._observation_spaces, self._action_spaces, self._type_num


    def han_reset(self):
        self._time_step = 0
        self._request_heapq = []

        self._link_usage   = [([0.] * self._node_num) for i in range(self._node_num)]
        self._delay_normal = [([1.] * self._node_num) for i in range(self._node_num)]
        self._loss_normal  = [([1.] * self._node_num) for i in range(self._node_num)]

        paths_state, rtype = self._my_update_state()
        state = []
        for i in range(4):
            if i == rtype:
                state.append(paths_state)
            else:
                state.append(self.default_state)

        # [
        #   [capa1, loss1, capa2, loss2] type1
        #   [capa1, loss1, capa2, loss2] type2
        #   [capa1, loss1, capa2, loss2] type3
        #   [capa1, loss1, capa2, loss2] type4
        # ]

        return state
    
    '''
    interact with controller and mininet to install path rules and generate request
    @retval:
        metrics of path including throughput, packet loss 
    '''
    def sim_interact(self, request, path):
        # install path in controller
        
        #print("linkucapa: {}".format(self._link_capa ))
        #print("current flow type: ", request.rtype)
        #print("type1: ", len(self._request_heapq_type1), " type2: ", len(self._request_heapq_type2), " type3: ", len(self._request_heapq_type3), " type4: ", len(self._request_heapq_type4))
        
        # print("\t\t Total demand: ", self.total_demand)
        data_js = {}
        data_js['path'] = path
        data_js['ipv4_src'] = "10.0.0.%d" % (request.s + 1)
        data_js['ipv4_dst'] = "10.0.0.%d" % (request.t + 1)

        # src_port = int(self._time_step % 10000 + 10000) + request.rtype
        # dst_port = int(self._time_step % 10000 + 10000) + request.rtype

        src_port = self.port
        dst_port = self.port

        data_js['src_port'] = src_port
        data_js['dst_port'] = dst_port

        msg = json.dumps(data_js)
        self.controller_socket.send(msg.encode())
        self.controller_socket.recv(self.BUFFER_SIZE)
        
        # communicate to testbed
        data_js = {}
        data_js['src'] = int(request.s)
        data_js['dst'] = int(request.t)

        data_js['src_port'] = src_port
        data_js['dst_port'] = dst_port

        data_js['rtype']  = int(request.rtype)
        data_js['demand'] = int(request.demand)
        data_js['rtime']  = int(request.end_time - request.start_time)
        msg = json.dumps(data_js)
        self.mininet_socket.send(msg.encode())
        # get the feedback
        msg = self.mininet_socket.recv(self.BUFFER_SIZE)
        data_js = json.loads(msg)


        if self.port > 20000:
            self.port = 10000
        self.port += 1

        return data_js
    
    
    def get_least_selected_path(self):
        for u, v, d in self.G.edges(data=True):
            d['weight'] = self._link_select_times[u-1][v-1]

        print(self._link_select_times)
        return (nx.dijkstra_path(self.G, self._request.s, self._request.t))


    def get_k_shortest_paths(self, request, topk):
        k = topk
        res = []
        if k == 0:
            return res
            
        X = nx.shortest_simple_paths(self.G, request.s, request.t)
        for counter, path in enumerate(X):
             res.append(path)
             if counter == k-1:
                 break
        return res


    def get_potential_paths(self):
        k = self.k
        self._paths = self.get_k_shortest_paths(self._request, k)

        path_t = self.calcBCSHR(self._request.s, self._request.t, self._request.demand)
        if path_t == None:
            path_t = self.calcWP(self._request.s, self._request.t)
        self._paths.append(path_t)

        # path_t = self.get_least_selected_path()
        # self._paths.append(path_t)

        self._paths_state = []
        one_hot_state_ = self.get_one_hot_state(self._request) 

        num_paths = self.num_paths
        for i in range(num_paths):
            self._paths_state.extend( self.get_path_state(self._paths[i], self._request, one_hot_state_) )

        self._paths_state.extend(one_hot_state_)

        return self._paths_state


    def get_one_hot_state(self, request):
        res = []
        for i in range(self._node_num):
            res.append(0)

        res[request.s] = 0
        res[request.t] = 0

        return res


    def get_path_state(self, path, request, one_hot):
        if path == None:
            return [-100, -100]

        demand = request.demand
        path_length = len(path)
        src = path[0]
        dst = path[path_length-1]

        loss = 0
        capacity = 0
        band_used = 0

        path_capa  = []
        path_usage = []


        for i in range(path_length-1):
            path_capa.append(self._link_capa[path[i]][path[i + 1]])
            path_usage.append(self._link_usage[path[i]][path[i + 1]])
            #capacity = min(capacity, max( 0, self._link_capa[path[i]][path[i + 1]] - self._link_usage[path[i]][path[i + 1]] ))
            loss     = max(loss,     self._link_losses[path[i]][path[i + 1]] )
            one_hot[path[i]] += 1
            if(i == path_length-2):
                one_hot[path[i+1]] += 1


        min_capa  = min(path_capa)
        max_capa  = max(path_capa) + 1
        avg_capa  = sum(path_capa) / len(path_capa)

        min_usage = min(path_usage)
        max_usage = max(path_usage) + 1
        avg_usage = sum(path_usage) / len(path_usage)


        avg_left = avg_usage - avg_capa
        # capacity = max(capacity, 0)

        return [avg_left / max_capa, demand / max_capa, min_capa / max_capa, avg_capa / max_capa, min_usage / max_usage, avg_usage / max_usage, loss, -path_length / 12]


    def get_reward(self, ret_data, request, capacity, path):
        delay      = ret_data['delay']
        throughput = ret_data['throughput']
        loss_rate  = ret_data['loss']

        delay_cut  = min(1000, delay) # since 1000 is much larger than common delay
        
        self._delay_normal[request.s][request.t] = self._delay_discounted_factor * self._delay_normal[request.s][request.t] + (1 - self._delay_discounted_factor) * delay_cut
        delay_scaled = delay_cut / self._delay_normal[request.s][request.t]
        delay_sq = - delay_scaled
        
        self._loss_normal[request.s][request.t] = self._loss_discounted_factor * self._loss_normal[request.s][request.t] + (1 - self._loss_discounted_factor) * loss_rate
        loss_scaled = loss_rate / (0.01 + self._loss_normal[request.s][request.t])
        loss_sq = - loss_scaled
        
        throughput_log = np.log(0.5 + throughput / request.demand) #avoid nan
        
        # calc global rwd of the generated path 
        global_rwd = 0

        if self.args.MyUtili == "myuti":
            my_delay = (self.args.delay_base - delay) / self.args.delay_base
            if self.args.uniDemand:
                # my_throu = (throughput - request.demand) / self.args.Demand_val
                my_throu = ((throughput / request.demand) - self.args.thr_ratio_base) / self.args.thr_ratio_base
            else:
                my_throu = (throughput - request.demand) / request.demand
            
            my_loss  = (self.args.loss_base - loss_rate) # fixed


            
            if request.rtype == 0:
                # if delay < self.args.delay_base:
                #     global_rwd = 1
                # else:
                #     global_rwd = 0
                global_rwd = 1 * my_delay
            elif request.rtype == 1:
                # if throughput > request.demand:
                #     global_rwd = 1
                # else:
                #     global_rwd = 0
                global_rwd = 1 * my_throu
            elif request.rtype == 2:
                # if delay < self.args.delay_base and throughput > request.demand:
                #     global_rwd = 1
                # else:
                #     global_rwd = 0
                global_rwd = 0.5 * my_delay + 0.5 * my_throu
            else:
                # if delay < self.args.delay_base and loss_rate < self.args.loss_base:
                #     global_rwd = 1
                # else:
                #     global_rwd = 0
                global_rwd = 0.5 * my_delay + 0.5 * my_loss
            
        elif self.args.MyUtili == "thuti":
            if request.rtype == 0:
                global_rwd = 1 * delay_sq
            elif request.rtype == 1:
                global_rwd =  0. * (delay_sq) + 1 * throughput_log - 0. * min(request.demand / (capacity + 1), 1)
            elif request.rtype == 2:
                global_rwd = 0.5 * delay_sq + 0.5 * throughput_log
            else:
                global_rwd = 0.5 * delay_sq + 0.5 * loss_sq


        return global_rwd


    def add_to_log(self, ret_data, reward, request, log_delay_files, log_throughput_files, log_loss_files, log_reward_files):
        delay      = ret_data['delay']
        throughput = ret_data['throughput']
        loss_rate  = ret_data['loss']

        throughput_rate = throughput / request.demand

        rtype = request.rtype

        print(delay,           file=log_delay_files[rtype])
        print(throughput_rate, file=log_throughput_files[rtype])
        print(loss_rate,       file=log_loss_files[rtype])
        print(reward,          file=log_reward_files[rtype])


    '''
    use action to interact with the environment
    @param: 
        actions:[torch.tensor([x]), ... the next hop action for each agent
        gfactors: list:shape[node_num] shows the reward factor for the global and local rwd
    @retval:
        states:  [torch.tensor([x, y, ...]), ...]
        rewards: [torch.tensor([r]), ...]
        path: [start, x, y, z, ..., end]
    '''
    def han_step(self, actions, log_delay_files, log_throughput_files, log_loss_files, log_reward_files):
        # actions = [0, 1, 1, 0]
        # agent_type1 = 0, agent_type2 = 1, agent_type3 = 1, agent_type4 = 0
        temp_rtype = self._request.rtype
        action_path = self._paths[ actions[temp_rtype] ]

        # update sim network state
        capacity_type1 = 1e9
        path = action_path
        for i in range(len(path) - 1):
            capacity_type1 = min(capacity_type1, max( 0, self._link_capa[path[i]][path[i + 1]] - self._link_usage[path[i]][path[i + 1]] ))
            self._link_usage[path[i]][path[i + 1]] += self._request.demand

            self.G_link_select_times[path[i]][path[i + 1]] += 1
            self._link_select_times[path[i]][path[i + 1]] += 1
        # self.total_demand += self._request.demand
        capacity_type1 = max(capacity_type1, 0)


        self._request.path = copy.copy(action_path)

        
        #interact with sim-env(ryu + mininet)
        ret_data = self.sim_interact(self._request, action_path)

        reward = self.get_reward(ret_data, self._request, capacity_type1, action_path)

        self.add_to_log(ret_data, reward, self._request, log_delay_files, log_throughput_files, log_loss_files, log_reward_files)
        
        rewards = []
        for i in range(4):
            rewards.append(reward)

        # generate new state
        self._time_step += 1
        paths_state, rtype = self._my_update_state()

        state = []
        for i in range(4):
            if i == rtype:
                state.append(paths_state)
            else:
                state.append(self.default_state)

        return state, rewards
    

    def _my_update_state(self):
        while len(self._request_heapq) > 0 and self._time_step >= self._request_heapq[0].end_time :
            request = heapq.heappop(self._request_heapq)
            path    = request.path
            if path != None:
                # self.total_demand -= request.demand
                for i in range(len(path) - 1):
                    self._link_usage[path[i]][path[i + 1]] -= request.demand
                    self._link_select_times[path[i]][path[i + 1]] -= 1

        # generate new request
        nodelist = range(self._node_num)
        start_time = self._time_step

        rtype = rtype = self._time_step % 4
        ind = weight_choice(self._demand_matrix)
        s = ind // self._node_num
        t = ind % self._node_num
        demand = random.choice(self._request_demands[rtype])

        end_time = start_time + random.choice(self._request_times[rtype])
        self._request = Request(s, t, start_time, end_time, demand, rtype)
        heapq.heappush(self._request_heapq, self._request)

        return self.get_potential_paths(), rtype


    '''
    load the topo and setup the environment
    '''
    def _load_topology(self, toponame, demand_matrix_name):
        data_path = os.path.dirname(os.path.realpath(__file__)) + "/inputs/"
        topofile = open(data_path + toponame + "/" + toponame + ".txt", "r")
        demandfile = open(data_path + toponame + "/" + demand_matrix_name, "r")
        self._demand_matrix = list(map(int, demandfile.readline().split()))
        # the input file is undirected graph while here we use directed graph
        # node id for input file indexed from 1 while here from 0
        self._node_num, edge_num = list(map(int, topofile.readline().split()))
        self._edge_num = edge_num * 2
        self._observation_spaces = []
        self._action_spaces = []
        
        # build the link list
        self._link_lists = [[] for i in range(self._node_num)] # neighbor for each node
        self._link_capa = [([0] * self._node_num) for i in range(self._node_num)]
        self._link_usage = [([0] * self._node_num) for i in range(self._node_num)]
        self._link_losses = [([0] * self._node_num) for i in range(self._node_num)]

        self.G_link_select_times = [([1] * self._node_num) for i in range(self._node_num)]
        self._link_select_times = [([1] * self._node_num) for i in range(self._node_num)]
        self.G = nx.DiGraph()

        for i in range(edge_num):
            u, v, _, c, loss = list(map(int, topofile.readline().split()))
            # since node index range from 1 to n in input file
            self._link_lists[u - 1].append(v - 1)
            self._link_lists[v - 1].append(u - 1)

            self.G.add_edge((u-1), (v-1))
            self.G.add_edge((v-1), (u-1))

            # undirected graph to directed graph
            self._link_capa[u - 1][v - 1] = c
            self._link_capa[v - 1][u - 1] = c
            self._link_losses[u - 1][v - 1] = loss
            self._link_losses[v - 1][u - 1] = loss
        
        # nx.draw(self.G, with_labels=True)
        # plt.draw()
        # plt.savefig("{}_topo.png".format(toponame))

        # input agent index
        is_agent = list(map(int, topofile.readline().split()))
        self._agent_to_node = []
        self._node_to_agent = [None] * self._node_num
        for i in range(self._node_num):
            if is_agent[i] == 1:
                self._node_to_agent[i] = len(self._agent_to_node)
                self._agent_to_node.append(i)
        self._agent_num = len(self._agent_to_node)

        # calsulate shortest path distance
        self._shr_dist = []
        for i in range(self._node_num):
            self._shr_dist.append([])
            for j in range(self._node_num):
                if j == i:
                    self._shr_dist[i].append(0)
                elif j in self._link_lists[i]:
                    self._shr_dist[i].append(1)
                else:
                    self._shr_dist[i].append(1e6) # inf
        for k in range(self._node_num):
            for i in range(self._node_num):
                for j in range(self._node_num):
                    if(self._shr_dist[i][j] > self._shr_dist[i][k] + self._shr_dist[k][j]):
                        self._shr_dist[i][j] = self._shr_dist[i][k] + self._shr_dist[k][j] 
        
        # generate observation spaces and action spaces
        for i in self._agent_to_node:
            # state: extra_state + neighbor_wp + neighbor shr(or least delay) + linkusage + link_losses + onehot type state + onehot src + dst state
            self._observation_spaces.append(spaces.Box(0., 1., [1 + self._node_num * len(self._link_lists[i]) + self._node_num * len(self._link_lists[i]) + self._node_num ** 2 + self._node_num ** 2 + self._type_num + self._node_num * 2], dtype=np.float32)) # maximum observation state
            # self._observation_spaces.append(spaces.Box(0., 1., [1 + len(self._link_lists[i]) + len(self._link_lists[i]) + self._type_num + self._node_num * 2], dtype=np.float32)) # only use neighbor state space
            self._action_spaces.append(spaces.Discrete(len(self._link_lists[i])))
        
        # TO BE CHECKED BEFORE EXPERIMENT
        # setup flow generating step
        if toponame == "Abi":
            self._request_demands = [[100], [1500], [1500], [500]]
            # self._request_times = [[50], [50], [50], [50]] # heavy load
            # self._request_times = [[10], [10], [10], [10]] # light load
            # self._request_times = [[30], [30], [30], [30]] # mid load
            self._request_times = self.args.request_times
        elif toponame == "GEA":
            self._request_demands = [[100], [1500], [1500], [500]]
            # self._request_times = [[15], [15], [15], [15]]
            self._request_times = self.args.request_times

        print(toponame)
        print(self._request_times)
        print()
    

    def draw_statistics(self):
        toponame = self.args.env_name
        data_path = os.path.dirname(os.path.realpath(__file__)) + "/inputs/"
        topofile = open(data_path + toponame + "/" + toponame + ".txt", "r")

        statistic_G = nx.DiGraph()

        max_time = 0
        for i in range(self._node_num):
            for j in range(self._node_num):
                max_time = max(max_time, self.G_link_select_times[i][j])
        
        for i in range(self._node_num):
            for j in range(self._node_num):
                self.G_link_select_times[i][j] /= max_time

        topofile.readline()
        for i in range(int(self._edge_num / 2)):
            u, v, _, c, loss = list(map(int, topofile.readline().split()))

            statistic_G.add_edge((u-1), (v-1), weight=self.G_link_select_times[u-1][v-1] * 10)
            statistic_G.add_edge((v-1), (u-1), weight=self.G_link_select_times[v-1][u-1] * 10)

        print(self.G_link_select_times)

        weights = nx.get_edge_attributes(statistic_G, 'weight').values()

        pos = nx.circular_layout(statistic_G)
        # pos = nx.spring_layout(statistic_G)
        nx.draw(statistic_G, pos, 
                width=list(weights),
                with_labels=True,
                node_color='lightgreen')

        plt.draw()
        plt.savefig("{}_statistic.png".format(toponame))


    '''
        changing network status:
        link failure
        demand changing
    '''
    def change_env(self, msg):
        if msg == "link_failure":
            # Abi link failure 1-5
            self._link_capa[0][4] = 0
            self._link_capa[4][0] = 0
            
            # calculate shortest path distance for new topology
            self._shr_dist = []
            for i in range(self._node_num):
                self._shr_dist.append([])
                for j in range(self._node_num):
                    if j == i:
                        self._shr_dist[i].append(0)
                    elif (j in self._link_lists[i]) and (self._link_capa[i][j] > 0):
                        self._shr_dist[i].append(1)
                    else:
                        self._shr_dist[i].append(1e6) # inf
            for k in range(self._node_num):
                for i in range(self._node_num):
                    for j in range(self._node_num):
                        if(self._shr_dist[i][j] > self._shr_dist[i][k] + self._shr_dist[k][j]):
                            self._shr_dist[i][j] = self._shr_dist[i][k] + self._shr_dist[k][j] 
        elif msg == "demand_change":
            # from light load to mid load, may be for heavy load in the future
            self._request_times = [[30], [30], [30], [30]]
        else:
            raise NotImplementedError

    '''
    calculating the Widest Path from s to t
    '''
    def calcWP(self, s, t):
        fat = [-1] * self._node_num
        WP_dist = [- 1e6] * self._node_num
        flag = [False] * self._node_num
        WP_dist[t] = 1e6
        flag[t] = True
        cur_p = t
        while flag[s] == False:
            for i in self._link_lists[cur_p]:
                #bandwidth = max(self._link_capa[i][cur_p] - self._link_usage[i][cur_p], 0)
                bandwidth = self._link_capa[i][cur_p] - self._link_usage[i][cur_p] # for testing
                if min(bandwidth, WP_dist[cur_p]) > WP_dist[i]:
                    WP_dist[i] = min(bandwidth, WP_dist[cur_p])
                    fat[i] = cur_p
            cur_p = -1
            for i in range(self._node_num):
                if flag[i]:
                    continue
                if cur_p == -1 or WP_dist[i] > WP_dist[cur_p]:
                    cur_p = i
            flag[cur_p] = True
    
        path = [s]
        cur_p = 0
        while path[cur_p] != t:
            path.append(fat[path[cur_p]])
            cur_p += 1
        return path
    
    
    '''
    calculating the Shortest Path from s to t
    '''
    def calcSHR(self, s, t):
        path = [s]
        cur_p = 0
        while path[cur_p] != t:
            tmp_dist = 1e6
            next_hop = None
            for i in self._link_lists[path[cur_p]]:
                if self._shr_dist[i][t] < tmp_dist and self._link_capa[path[cur_p]][i] > 0:
                    next_hop = i
                    tmp_dist = self._shr_dist[i][t]
            path.append(next_hop)
            cur_p += 1
        return path
    
    '''
    calculating the Bandwidth-Constrained Shortest Path
    '''
    def calcBCSHR(self, s, t, demand):
        fat = [-1] * self._node_num
        SHR_dist = [1e6] * self._node_num
        flag = [False] * self._node_num
        SHR_dist[t] = 0
        flag[t] = True
        cur_p = t
        
        while flag[s] == False:
            for i in self._link_lists[cur_p]:
                #bandwidth = max(self._link_capa[i][cur_p] - self._link_usage[i][cur_p], 0)
                bandwidth = self._link_capa[i][cur_p] - self._link_usage[i][cur_p] 
                if bandwidth >= demand and SHR_dist[i] > SHR_dist[cur_p] + 1:
                    SHR_dist[i] = SHR_dist[cur_p] + 1
                    fat[i] = cur_p
            cur_p = -1
            for i in range(self._node_num):
                if flag[i]:
                    continue
                if cur_p == -1 or SHR_dist[i] < SHR_dist[cur_p]:
                    cur_p = i
            if SHR_dist[cur_p] < 1e6:
                flag[cur_p] = True
            else:
                break
    
        if not flag[s]:
            return None
        path = [s]
        cur_p = 0
        while path[cur_p] != t:
            path.append(fat[path[cur_p]])
            cur_p += 1
        return path

    '''
    method = "SHR"/"WP"/"DS"(diff-serv)
    '''
    def step_baseline(self, method):
        if method == "SHR":
            path = self.calcSHR(self._request.s, self._request.t)
        elif method == "WP":
            path = self.calcWP(self._request.s, self._request.t)
        elif method == "DS":
            if self._request.rtype == 0 or self._request.rtype == 3:
                path = self.calcSHR(self._request.s, self._request.t)
            elif self._request.rtype == 1:
                path = self.calcWP(self._request.s, self._request.t)
            else:
                path = self.calcBCSHR(self._request.s, self._request.t, self._request.demand)
                if path == None:
                    path = self.calcWP(self._request.s, self._request.t)
        elif method == 'QoS':
            path = self.calcBCSHR(self._request.s, self._request.t, self._request.demand)
            if path == None:
                path = self.calcWP(self._request.s, self._request.t)
        else:
            raise NotImplementedError
        self._request.path = copy.copy(path)

        # update link usage according to the selected path 
        capacity = 1e9
        for i in range(len(path) - 1):
            capacity = min(capacity, max(0, self._link_capa[path[i]][path[i + 1]] - self._link_usage[path[i]][path[i + 1]]))
            self._link_usage[path[i]][path[i + 1]] += self._request.demand
        count = len(path) - 1
        
        # install rules for path and generate service request in sim-env(ryu + mininet)
        ret_data = self.sim_interact(self._request, path)
        delay = ret_data['delay']
        throughput = ret_data['throughput']
        loss_rate = ret_data['loss']
        
        delta_dist = count - self._shr_dist[self._request.s][self._request.t]
        delta_demand = min(capacity, self._request.demand) / self._request.demand
        throughput_rate = throughput / self._request.demand
        rtype = self._request.rtype
        
        max_link_util = 0.
        for i in range(self._node_num):
            for j in range(self._node_num):
                if self._link_capa[i][j] > 0:
                    max_link_util = max(max_link_util, self._link_usage[i][j] / self._link_capa[i][j])
        print("max link utility:", max_link_util)

        # generate new state
        self._time_step += 1
        self._update_state()
        return rtype, delta_dist, delta_demand, delay, throughput_rate, loss_rate


if __name__ == "__main__":
    toponame = sys.argv[1]
    method   = sys.argv[2] # baseline method can be SHR | WP | DS | QoS
    num_step = int(sys.argv[3])

    if toponame == "Abi":
        demand_matrix = "Abi_500.txt"
    else:
        demand_matrix = "GEA_500.txt"

    # setup env
    args = None 
    envs = NetEnv(args) 
    num_agent, num_node, observation_spaces, action_spaces, num_type = envs.setup(toponame, demand_matrix)
    envs.reset()
    
    # open log file
    log_dir = "../log/%s_%s_%d_simenv_heavyload_1-5loss/" % (toponame, method, num_step)
    try:
        os.makedirs(log_dir)
    except OSError:
        files = glob.glob(os.path.join(log_dir, '*.log'))
        for f in files:
            os.remove(f)
    
    log_dist_files   = []
    log_demand_files = []
    log_delay_files  = []
    log_throughput_files = []
    log_loss_files = []

    for i in range(num_type):
        log_dist_file = open("%s/dist_type%d.log" % (log_dir, i), "w", 1)
        log_dist_files.append(log_dist_file)
        log_demand_file = open("%s/demand_type%d.log" % (log_dir, i), "w", 1)
        log_demand_files.append(log_demand_file)
        log_delay_file = open("%s/delay_type%d.log" % (log_dir, i), "w", 1)
        log_delay_files.append(log_delay_file)
        log_throughput_file = open("%s/throughput_type%d.log" % (log_dir, i), "w", 1)
        log_throughput_files.append(log_throughput_file)
        log_loss_file = open("%s/loss_type%d.log" % (log_dir, i), "w", 1)
        log_loss_files.append(log_loss_file)

    for i in range(num_step):
        print("step:", i)
        rtype, delta_dist, delta_demand, delay, throughput_rate, loss_rate = envs.step_baseline(method)
        print(delta_dist, file=log_dist_files[rtype])
        print(delta_demand, file=log_demand_files[rtype])
        print(delay, file=log_delay_files[rtype])
        print(throughput_rate, file=log_throughput_files[rtype]) 
        print(loss_rate, file=log_loss_files[rtype])
