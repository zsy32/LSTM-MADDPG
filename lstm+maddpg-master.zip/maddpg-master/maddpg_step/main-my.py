import os
import time
import copy
import glob

from collections import deque

import gym
import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim


from runner           import Runner

from net_env.simenv   import NetEnv
from common.arguments import get_args


def main():
    args = get_args()
    device = torch.device("cuda:0" if args.cuda else "cpu")
    
    #set up environment
    envs = NetEnv(args) 
    num_agent, num_node, observation_spaces, action_spaces, num_type = envs.setup(args.env_name, args.demand_matrix)
    link_usage_as_state = envs.han_reset()


    SEED = 2
    np.random.seed(SEED)
    # random.seed(SEED) 
    torch.manual_seed(SEED) #为CPU设置种子用于生成随机数，以使得结果是确定的
    torch.cuda.manual_seed(SEED)

    print("Initialize Runner")
    runner = Runner(args, envs)

    print("Calling method run()")
    runner.run()

    envs.draw_statistics()


    # open log file
    # log_dist_files   = []
    # log_demand_files = []
    # log_delay_files  = []
    # log_throughput_files = []
    # log_loss_files   = []
    # for i in range(num_type):
    #     log_dist_file = open("%s/dist_type%d.log" % (log_dir, i), "w", 1)
    #     log_dist_files.append(log_dist_file)
    #     log_demand_file = open("%s/demand_type%d.log" % (log_dir, i), "w", 1)
    #     log_demand_files.append(log_demand_file)
    #     log_delay_file = open("%s/delay_type%d.log" % (log_dir, i), "w", 1)
    #     log_delay_files.append(log_delay_file)
    #     log_throughput_file = open("%s/throughput_type%d.log" % (log_dir, i), "w", 1)
    #     log_throughput_files.append(log_throughput_file)
    #     log_loss_file = open("%s/loss_type%d.log" % (log_dir, i), "w", 1)
    #     log_loss_files.append(log_loss_file)
    # log_globalrwd_file = open("%s/globalrwd.log" % (log_dir), "w", 1)
    # log_circle_file = open("%s/circle.log" % (log_dir), "w", 1)

    

if __name__ == "__main__":
    main()
