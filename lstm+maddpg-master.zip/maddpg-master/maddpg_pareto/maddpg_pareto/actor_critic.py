import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F


# define the actor network
class Actor(nn.Module):
    def __init__(self, args, agent_id):
        super(Actor, self).__init__()
        # self.max_action = args.high_action
        # self.input = args.obs_shape[agent_id]
        self.args = args

        self.input1 = nn.Linear(self.args.feature_per_path, self.args.feature_per_path)
        self.input2 = nn.Linear(self.args.feature_per_path, self.args.feature_per_path)

        # self.fc1 = nn.Linear(args.obs_shape[agent_id], 64)
        self.fc1 = nn.Linear(self.args.feature_per_path, 1)
        self.fc2 = nn.Linear(self.args.feature_per_path, 1)

        # self.fc3 = nn.Linear(self.args.feature_per_path, 1)
        # self.fc4 = nn.Linear(self.args.feature_per_path, 1)
        # self.fc5 = nn.Linear(self.args.feature_per_path, 1)
        # self.fc6 = nn.Linear(self.args.feature_per_path, 1)

        # self.one_hot_fc = nn.Linear(self.args.node_num, 1)

        # self.one_hot_and_path1 = nn.Linear(2, 1)
        # self.one_hot_and_path2 = nn.Linear(2, 1)

        self.follow_fc = nn.Linear(2, 2)

        # self.action_out = nn.Linear(64, args.action_shape[agent_id])

    def forward(self, x):
        # print("inside actor")
        # print(self.input)
        # print(x.shape)
        # print("ok")
        # print(x)
        p1 = x[0][0 : self.args.feature_per_path].unsqueeze(0)
        p2 = x[0][1 * self.args.feature_per_path : 2 * self.args.feature_per_path].unsqueeze(0)

        # p3 = x[0][2 * self.args.feature_per_path : 3 * self.args.feature_per_path].unsqueeze(0)
        # p4 = x[0][3 * self.args.feature_per_path : 4 * self.args.feature_per_path].unsqueeze(0)
        # p5 = x[0][4 * self.args.feature_per_path : 5 * self.args.feature_per_path].unsqueeze(0)
        # p6 = x[0][5 * self.args.feature_per_path : 6 * self.args.feature_per_path].unsqueeze(0)

        # print(p1)
        # print(p2)

        # one_hot = x[0][2 * self.args.feature_per_path : ].unsqueeze(0)
        # x_one_hot = F.sigmoid(self.one_hot_fc(one_hot))

        x1 = F.sigmoid(self.fc1(self.input1(p1)))
        x2 = F.sigmoid(self.fc2(self.input2(p2)))

        # x3 = F.sigmoid(self.fc3(p3))
        # x4 = F.sigmoid(self.fc4(p4))
        # x5 = F.relu(self.fc5(p5))
        # x6 = F.relu(self.fc6(p6))

        # print(one_hot)
        # print(x1)
        # print(x2)
        # print(x_one_hot)

        # x1 = F.sigmoid(self.one_hot_and_path1(torch.cat((x1, x_one_hot), 1)))
        # x2 = F.sigmoid(self.one_hot_and_path2(torch.cat((x2, x_one_hot), 1)))

        # print(x1)
        # print(x2)

        # final = torch.cat((x1, x2, x3, x4, x5, x6), 1)
        concat = torch.cat((x1, x2), 1)
        # final  = concat

        # print("concat: ", concat)
        final = self.follow_fc(concat)
        # print("final: ", final)
        actions = F.softmax(final)
        # print("parameters: ", self.follow_fc.parameters())
        # print(actions)
        
        return actions


class Critic(nn.Module):
    def __init__(self, args):
        super(Critic, self).__init__()
        self.args = args
        
        self.input_o = nn.Linear(4, 4)
        # self.input_o = nn.Linear(self.args.obs_shape[0], 4)
        self.input_a = nn.Linear(2, 2)
        self.q_out = nn.Linear(6, 1)

    def forward(self, state, action):
        # action = torch.cat(action, dim=1)
        # action = action.view(1, -1)
        # action = action[0]

        # state = torch.cat(state, dim=1)
        # state = state.view(1, -1)
        # state = state[0]

        # x = torch.cat([state, action], dim=0)
        # x = F.relu(self.fc1(x))
        # x = F.relu(self.fc2(x))
        # x = F.relu(self.fc3(x))
        # q_value = self.q_out(x)
        # print(state)
        x = self.input_o(state)
        a = self.input_a(action)

        final = torch.cat((x, a), 1)
        q_value = self.q_out(final)

        return q_value


class gCritic(nn.Module):
    def __init__(self, args):
        super(gCritic, self).__init__()
        # self.max_action = args.high_action
        self.fc1 = nn.Linear(sum(args.obs_shape) + sum(args.action_shape), 64)
        # self.fc1 = nn.Linear(sum(args.obs_shape) + args.n_agents, 64)
        self.fc2 = nn.Linear(64, 64)
        self.fc3 = nn.Linear(64, 64)
        self.q_out = nn.Linear(64, 1)

    def forward(self, state, action):

        action = torch.cat(action, dim=1)
        action = action.view(1, -1)
        action = action[0]

        state = torch.cat(state, dim=1)
        state = state.view(1, -1)
        state = state[0]

        # action = torch.from_numpy(np.array(action))
        # action = torch.cat(action, dim=1)

        x = torch.cat([state, action], dim=0)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = F.relu(self.fc3(x))
        q_value = self.q_out(x)
        return q_value