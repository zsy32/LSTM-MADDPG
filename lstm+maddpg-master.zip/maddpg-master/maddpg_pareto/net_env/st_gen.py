import os


node_num = 11
toponame = "Abi"
demand_matrix_name = "{}_500.txt".format(toponame)

data_path = os.path.dirname(os.path.realpath(__file__)) + "/inputs/"
demandfile = open(data_path + toponame + "/" + demand_matrix_name, "r")
demand_matrix = list(map(int, demandfile.readline().split()))

if __name__ == "__main__":
    from utils import weight_choice
else:
    from net_env.utils import weight_choice

f = open("st_file_{}.txt".format(toponame), "w")

for i in range(24000):
    ind = weight_choice(demand_matrix)
    s = ind // node_num
    t = ind %  node_num
    rtype = i % 4

    print("{},{},{}".format(s, t, rtype), file = f)

# f = open("st_file_{}.txt".format(toponame), "r")

# x = f.readline()
# print(x.strip().split(","))
# x = f.readline()
# print(x.strip().split(","))
# x = f.readline()
# print(x.strip().split(","))