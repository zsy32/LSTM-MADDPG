import os
import time
import copy
import glob

from collections import deque

import gym
import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim


from runner           import Runner


from common.arguments import get_args



def main():
    args = get_args()
    device = torch.device("cuda:0" if args.cuda else "cpu")
    
    #set up environment
    from net_env.simenv   import NetEnv
    envs = NetEnv(args) 

    num_agent, num_node, observation_spaces, action_spaces, num_type = envs.setup(args.env_name, args.demand_matrix)
    link_usage_as_state = envs.han_reset()

    SEED = 1
    np.random.seed(SEED)
    torch.manual_seed(SEED) #为CPU设置种子用于生成随机数，以使得结果是确定的
    torch.cuda.manual_seed(SEED)

    print("Initialize Runner")
    runner = Runner(args, envs)

    print("Calling method run()")
    runner.run()

    # envs.draw_statistics()


def main_eval():
    print("Evaluating Main starto")
    args = get_args()
    device = torch.device("cuda:0" if args.cuda else "cpu")
    
    #set up environment
    from net_env.simenv_test   import NetEnv
    envs = NetEnv(args) 

    num_agent, num_node, observation_spaces, action_spaces, num_type = envs.setup(args.env_name, args.demand_matrix)
    link_usage_as_state = envs.han_reset()

    SEED = 1
    np.random.seed(SEED)
    torch.manual_seed(SEED) #为CPU设置种子用于生成随机数，以使得结果是确定的
    torch.cuda.manual_seed(SEED)

    print("Initialize Runner")
    runner = Runner(args, envs)

    print("Calling method run_eval()")
    runner.run_eval()

    envs.draw_statistics()

def main_coma():
    print("COMA Main starto")
    args = get_args()
    device = torch.device("cuda:0" if args.cuda else "cpu")
    
    #set up environment
    from net_env.simenv import NetEnv
    envs = NetEnv(args) 

    num_agent, num_node, observation_spaces, action_spaces, num_type = envs.setup(args.env_name, args.demand_matrix)
    link_usage_as_state = envs.han_reset()

    SEED = 1
    np.random.seed(SEED)
    torch.manual_seed(SEED) 
    torch.cuda.manual_seed(SEED)

    print("Initialize RunnerCOMA")
    from runner_coma import RunnerCOMA
    runner = RunnerCOMA(args, envs)

    print("Calling method run()")
    runner.run()

    # envs.draw_statistics()

if __name__ == "__main__":
    main()
    # main_eval()
    # main_coma()
