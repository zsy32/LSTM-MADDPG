import os
import time
import torch
import random

import numpy as np
import matplotlib.pyplot as plt

from tqdm  import tqdm

from maddpg_pareto.coma import COMA


class RunnerCOMA:
    def __init__(self, args, env):
        self.args    = args
        self.noise   = args.noise_rate

        self.env    = env
        self.agents = self._init_agents()

        self.epsilon       = args.epsilon
        self.episode_limit = args.max_episode_len
        
        self.save_path = self.args.save_dir + '/' + self.args.scenario_name
        if not os.path.exists(self.save_path):
            os.makedirs(self.save_path)

        self.grad_method = self.args.grad_method
        print("Initial time for each request: {}".format(self.args.my_request_times))


    def _init_logs(self):
        self.log_delay_files      = []
        self.log_throughput_files = []
        self.log_loss_files       = []
        self.log_reward_files     = []
        
        log_dir = self.args.log_dir
        os.makedirs(log_dir)
        for i in range(4):
            log_delay_file      = open("%s/delay_type%d.log" % (log_dir, i), "w", 1)
            self.log_delay_files.append(log_delay_file)

            log_throughput_file = open("%s/throughput_type%d.log" % (log_dir, i), "w", 1)
            self.log_throughput_files.append(log_throughput_file)

            log_loss_file       = open("%s/loss_type%d.log" % (log_dir, i), "w", 1)
            self.log_loss_files.append(log_loss_file)

            log_reward_file     = open("%s/reward_type%d.log" % (log_dir, i), "w", 1)
            self.log_reward_files.append(log_reward_file)

        self.log_path_file      = open("%s/path.log"   % (log_dir), "w", 1)


    def _init_logs_eval(self):
        self.log_delay_files      = []
        self.log_throughput_files = []
        self.log_loss_files       = []
        self.log_reward_files     = []
        
        log_dir_eval = self.args.log_dir_eval
        os.makedirs(log_dir_eval)
        for i in range(4):
            log_delay_file      = open("%s/delay_type%d.log" % (log_dir_eval, i), "w", 1)
            self.log_delay_files.append(log_delay_file)

            log_throughput_file = open("%s/throughput_type%d.log" % (log_dir_eval, i), "w", 1)
            self.log_throughput_files.append(log_throughput_file)

            log_loss_file       = open("%s/loss_type%d.log" % (log_dir_eval, i), "w", 1)
            self.log_loss_files.append(log_loss_file)

            log_reward_file     = open("%s/reward_type%d.log" % (log_dir_eval, i), "w", 1)
            self.log_reward_files.append(log_reward_file)

        self.log_path_file      = open("%s/path.log"   % (log_dir_eval), "w", 1)


    def _init_agents(self):
        agent_num = 4
        state_dim = self.args.obs_shape[0]
        action_dim = 2

        gamma = 0.99
        lr_a = 0.0001
        lr_c = 0.005
        target_update_steps = 10

        agents = COMA(agent_num, state_dim, action_dim, lr_c, lr_a, gamma, target_update_steps)
        return agents
    

    def _load_agents(self):
        print("loading trained model")
        for i in range(self.args.n_agents):
            model_path = os.path.join(self.args.save_dir, self.args.scenario_name)
            model_path = os.path.join(model_path, 'agent_%d' % i)
            self.agents[i].policy.actor_network.load_state_dict(torch.load(model_path + '/' + 'Abi4' + '_actor_params.pkl'))


    def run(self):
        self._init_logs()
        # action_history = {}
        # action_history["agent0"] = [0 for i in range(self.args.num_paths)]
        # action_history["agent1"] = [0 for i in range(self.args.num_paths)]
        # action_history["agent2"] = [0 for i in range(self.args.num_paths)]
        # action_history["agent3"] = [0 for i in range(self.args.num_paths)]

        for time_step in tqdm(range(self.args.time_steps)):
            # reset the environment
            if time_step % self.episode_limit == 0:
                s, critic_s = self.env.han_reset()

            u = []
            actions = []
            with torch.no_grad():
                actions = self.agents.get_actions(s)

            s_next, r, critic_s_next = self.env.han_step(actions, 
                                            self.log_delay_files, 
                                            self.log_throughput_files, 
                                            self.log_loss_files, 
                                            self.log_reward_files, 
                                            self.log_path_file)

            # print("\t\t\t", r)
            self.agents.memory.reward.append(r)
            for i in range(4):
                self.agents.memory.done[i].append(0)

            s = s_next
            critic_s = critic_s_next

            if time_step > 50 and time_step % 10 == 0:
                self.agents.train()
                    
            self.epsilon = max(0.005, self.epsilon - 0.0005)
        # print(action_history)


    def random_pick(self, some_list, probabilities):
        x=random.uniform(0,1)
        cumulative_probability=0.0
        for item,item_probability in zip(some_list,probabilities):
            cumulative_probability+=item_probability
            if x < cumulative_probability: break
        return item


    def run_eval(self):
        self._load_agents()
        self._init_logs_eval()

        action_history = {}
        action_history["agent0"] = [0 for i in range(self.args.num_paths)]
        action_history["agent1"] = [0 for i in range(self.args.num_paths)]
        action_history["agent2"] = [0 for i in range(self.args.num_paths)]
        action_history["agent3"] = [0 for i in range(self.args.num_paths)]

        for time_step in tqdm(range(self.args.time_steps)):
            if time_step % self.episode_limit == 0:
                s, rtype = self.env.han_reset()

            u = []
            actions = []
            
            with torch.no_grad():
                for agent_id, agent in enumerate(self.agents):
                    #start = time.time()
                    # print(agent_id)
                    action = agent.select_action_eval(s[agent_id], self.noise, self.epsilon)
                    # print("\t\t\t\t\t\tselected actions:", action)
                    #finish = time.time()
                    #print("time to make actions for all agents: ", finish - start)
                    action_proba = action.tolist()[0]
                    print(action_proba)

                    temp_a = self.random_pick( [i for i in range(self.args.num_paths)], action_proba )
                    # temp_a = action.argmax().numpy()
                    print(temp_a)

                    actions.append(temp_a)
                    if rtype == agent_id:
                        action_history["agent{}".format(agent_id)][temp_a] += 1

            print(actions)
            s_next, r, rtype = self.env.han_step(actions, 
                                            self.log_delay_files, 
                                            self.log_throughput_files, 
                                            self.log_loss_files, 
                                            self.log_reward_files, 
                                            self.log_path_file)

            s = s_next

            self.epsilon = max(0.005, self.epsilon - 0.0005)
        print(action_history)

